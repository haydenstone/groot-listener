# Changelog

## 0.19.1
- New flyable city game mode with mouse-look, WASD flight, vertical movement and boost.
- Independent resident locomotion in the 3D city; party members may follow only when toggled.
- Correct front/back avatar rendering: eyes are drawn only when a character is actually facing the camera.
- More articulated gestures: walking, waving, looking and pointing.
- Observation Beacon Run and City Systems Loop game missions.
- Truce, Klus and Ayoh discovered from the city API as optional game companions.
- Map mode remains available as a quiet fallback.

## 0.18.0

- Fresh-instance City/Path architecture with resettable GROOT state.
- Built 3D-style City home screen and per-resident phone UI.
- Stone-family-only active-page explorer scope.
- Host-side path trace evidence and 30-second UI monitoring mode.
- Unified browser-observed API Scout.
- Bounded Nautilus-style workspace APIs and file editor.
- Ollama-backed Swarm Website Builder.
- Labeled/static Docker POC lifecycle controls.
- New v0.18 browser/local-storage namespace to avoid carrying old AR persistence into the new city.
