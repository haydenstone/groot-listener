# GROOT City Path Observatory v0.19.1

Fresh-instance release. It intentionally starts with new GROOT runtime/UI/browser namespaces and a clean workspace while preserving external Ollama models and Piper voices.

## What changed

- **GROOT City** is the local home world. Every discovered persona receives a deterministic home, a phone UI, and an individual city identity.
- **Stone-family page expedition**: only Hayden Stone, Ava Stone, Truce Stone, and Klus Stone are eligible for the injected active-page crew by default. The wider roster remains in City and on research/fellowship mission boards unless Hayden explicitly assigns a destination.
- **Path Observatory**: host-side DNS, route lookup, and `tracepath`/`traceroute` evidence. It reports responding/observed hops only; silent routers are never invented.
- **Page/API Scout**: keeps the browser-observed API/resource tree and interesting-node ranking from earlier releases.
- **Swarm Builder**: asks the local Ollama-backed swarm to produce a standalone website POC inside the bounded workspace.
- **Nautilus-style workspace**: browse, read, write, create folders, and delete empty directories/files only under `workspace/`.
- **Light Docker POC management**: can spin and control only containers labeled `groot.poc=true`, and only from generated `workspace/sites/<slug>` directories.
- **Fresh browser namespace**: v0.19 uses new extension/local-storage keys so old house/UI state does not bleed into the new city.

## Fresh start

From a new extracted v0.19 directory:

```bash
./bootstrap.sh doctor
./bootstrap.sh --fresh-state --docker existing --docker-group add --ollama safe --piper on up
```

`--fresh-state` clears only this release's GROOT runtime/UI/expedition/workspace state. It does **not** delete:

```text
$HOME/Documents/ollama
$HOME/Documents/piper-voices
```

Open:

```text
http://127.0.0.1:8787
```

Reload the unpacked Chrome extension from:

```bash
./grootctl extension-path
```

Generate a new v0.19 one-liner, rather than reusing an older one:

```bash
./grootctl js-ar
```

## Path observability

```bash
./grootctl path-capabilities
./grootctl path-trace example.com
./grootctl path-history
```

If neither `tracepath` nor `traceroute` is installed, GROOT still returns DNS and route evidence, but hop discovery will say the trace tool is unavailable. On Ubuntu, `tracepath` is typically provided by `iputils-tracepath`.

## Workspace and Swarm Builder

```bash
./grootctl workspace
./grootctl swarm-build demo "Build a polished single-file observability website"
```

Generated sites appear under:

```text
workspace/sites/<slug>/index.html
```

They can be previewed through the relay or started as an isolated static proof-of-concept container from the UI.

## Docker POCs

```bash
./grootctl docker-pocs
./grootctl docker-spin demo
```

The host-side controller refuses management of containers that do not have the `groot.poc=true` label and `groot-poc-` name prefix.

## Security / observability boundaries

GROOT City is an observability and development tool, not an unrestricted crawler. Browser API trees come from activity the browser actually observed. Path tracing is limited to a destination supplied by the operator and does not scan ports or networks. Workspace write access is bounded to the GROOT workspace. Docker actions are limited to GROOT-labeled POC containers.

Background science/technology/fellowship roles in City are mission assignments, not claims that persona processes are independently conscious or autonomously browsing the public Internet. External destinations require explicit operator assignment/opening.

## v0.19 flyable city game
Open **CITY** and use the FLY mode:

- click the canvas to capture mouse look
- `W A S D` move
- `SPACE` ascend
- `CTRL` descend
- `SHIFT` boost
- `E` interact with the resident under the crosshair
- `G` cycle a nearby resident gesture
- `ESC` releases mouse capture

Game missions are supplied by `/api/city`, not hardcoded into the browser. The default game party is also discovered from the city configuration. Avatar faces now have explicit front/back semantics, so eyes are never rendered on the rear of the head.
