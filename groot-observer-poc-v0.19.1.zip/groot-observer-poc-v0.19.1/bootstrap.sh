#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$ROOT"
STATE="$ROOT/.groot/state"; mkdir -p "$STATE" "$ROOT/logs" "$ROOT/data"
DOCKER_MODE="auto"; DOCKER_GROUP="auto"; OLLAMA_MODE="keep"; OLLAMA_MODEL_OVERRIDE=""; OLLAMA_EXTERNAL_URL="http://127.0.0.1:11434"; PIPER_MODE="keep"; ACTION="up"; PURGE_DOCKER="no"; PULL_MODEL="no"; FRESH_STATE="no"
usage(){ cat <<EOF
GROOT City Path bootstrap v0.19.1
Usage: ./bootstrap.sh [options] [up|down|status|doctor|uninstall]
  --docker auto|install|existing|off       Docker switch (default: auto)
  --docker-group auto|add|skip             Docker group membership (default: auto)
  --ollama keep|off|auto|safe|balanced|external  Local AI preset (default: keep)
  --ollama-model NAME                      Optional model hint / model to pull
  --ollama-url URL                         External Ollama URL
  --pull-model yes|no                      Pull --ollama-model after start (default: no)
  --piper keep|off|on                      Dockerized Piper (default: keep)
  --fresh-state                            Clear this release's GROOT runtime/UI/workspace state before first start
  --purge-docker                           With uninstall, remove Docker only if GROOT installed it

Recommended after first setup:
  ./bootstrap.sh --fresh-state --docker existing --ollama safe --piper on up

Subsequent starts preserve the configured AI/Piper profiles:
  ./bootstrap.sh --docker existing up

Ollama models persist at the invoking user's Documents/ollama directory.
EOF
}
while [[ $# -gt 0 ]]; do case "$1" in
  --docker) DOCKER_MODE="${2:?missing docker mode}"; shift 2;; --docker=*) DOCKER_MODE="${1#*=}"; shift;;
  --docker-group) DOCKER_GROUP="${2:?missing docker group mode}"; shift 2;; --docker-group=*) DOCKER_GROUP="${1#*=}"; shift;;
  --ollama) OLLAMA_MODE="${2:?missing ollama mode}"; shift 2;; --ollama=*) OLLAMA_MODE="${1#*=}"; shift;;
  --ollama-model) OLLAMA_MODEL_OVERRIDE="${2:?missing model}"; shift 2;; --ollama-model=*) OLLAMA_MODEL_OVERRIDE="${1#*=}"; shift;;
  --ollama-url) OLLAMA_EXTERNAL_URL="${2:?missing URL}"; shift 2;; --ollama-url=*) OLLAMA_EXTERNAL_URL="${1#*=}"; shift;;
  --pull-model) PULL_MODEL="${2:?missing pull mode}"; shift 2;; --pull-model=*) PULL_MODEL="${1#*=}"; shift;;
  --piper) PIPER_MODE="${2:?missing piper mode}"; shift 2;; --piper=*) PIPER_MODE="${1#*=}"; shift;;
  --fresh-state) FRESH_STATE="yes"; shift;; --purge-docker) PURGE_DOCKER="yes"; shift;; -h|--help) usage; exit 0;;
  up|down|status|doctor|uninstall) ACTION="$1"; shift;; *) echo "Unknown argument: $1" >&2; usage; exit 2;;
esac; done
[[ "$DOCKER_MODE" =~ ^(auto|install|existing|off)$ ]] || { echo "Invalid --docker mode" >&2; exit 2; }
[[ "$DOCKER_GROUP" =~ ^(auto|add|skip)$ ]] || { echo "Invalid --docker-group mode" >&2; exit 2; }
[[ "$OLLAMA_MODE" =~ ^(keep|off|auto|safe|8gb-safe|balanced|8gb-balanced|on|external)$ ]] || { echo "Invalid --ollama mode" >&2; exit 2; }
[[ "$PIPER_MODE" =~ ^(keep|off|on|safe|8gb)$ ]] || { echo "Invalid --piper mode" >&2; exit 2; }
[[ "$PULL_MODEL" =~ ^(yes|no)$ ]] || { echo "Invalid --pull-model mode" >&2; exit 2; }
have_docker_cli(){ command -v docker >/dev/null 2>&1; }
have_docker_direct(){ docker info >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; }
have_docker_sudo(){ command -v sudo >/dev/null 2>&1 && sudo docker info >/dev/null 2>&1 && sudo docker compose version >/dev/null 2>&1; }
have_docker(){ have_docker_cli && { have_docker_direct || have_docker_sudo; }; }
ensure_venv(){ GROOT_ROOT="$ROOT" GROOT_STATE_DIR="$STATE" "$ROOT/scripts/ensure-python-venv.sh"; }
ensure_group(){ GROOT_STATE_DIR="$STATE" "$ROOT/scripts/ensure-docker-group.sh" add; }
configure_ollama(){ GROOT_ROOT="$ROOT" GROOT_STATE_DIR="$STATE" OLLAMA_MODEL_OVERRIDE="${OLLAMA_MODEL_OVERRIDE:-auto}" OLLAMA_EXTERNAL_URL="$OLLAMA_EXTERNAL_URL" "$ROOT/scripts/configure-ollama.sh" "$1"; }
configure_piper(){ GROOT_ROOT="$ROOT" GROOT_STATE_DIR="$STATE" "$ROOT/scripts/configure-piper.sh" "$1"; }
if [[ "$ACTION" == doctor ]]; then
  echo "GROOT doctor v0.19.1"; echo "root=$ROOT"; echo "user=${SUDO_USER:-${USER:-$(id -un)}}"; awk '/MemTotal:/ {printf "memory_mib=%d\n", $2/1024}' /proc/meminfo 2>/dev/null || true
  if command -v python3 >/dev/null 2>&1; then echo "python=$(python3 --version 2>&1)"; else echo "python=missing"; fi
  if have_docker_cli; then echo "docker_cli=$(docker --version 2>/dev/null || true)"; if have_docker_direct; then echo "docker_access=direct"; elif have_docker_sudo; then echo "docker_access=sudo"; else echo "docker_access=daemon_or_compose_unavailable"; fi; else echo "docker_cli=missing"; fi
  [[ -f "$STATE/runtime-mode" ]] && echo "runtime_mode=$(cat "$STATE/runtime-mode")" || echo "runtime_mode=not_selected"
  [[ -f "$STATE/ollama.env" ]] && grep -E '^(GROOT_OLLAMA_PROFILE|OLLAMA_MODEL|OLLAMA_DATA_DIR|OLLAMA_MEMORY_LIMIT|OLLAMA_CPUS|OLLAMA_CONTEXT_LENGTH)=' "$STATE/ollama.env" || echo "ollama_profile=not_configured"
  [[ -f "$STATE/piper.env" ]] && grep -E '^(GROOT_PIPER_PROFILE|PIPER_DATA_DIR|PIPER_MEMORY_LIMIT|PIPER_CPUS)=' "$STATE/piper.env" || echo "piper_profile=not_configured"
  "$ROOT/grootctl" device-status || true; exit 0
fi
if [[ "$ACTION" == uninstall ]]; then
  "$ROOT/grootctl" down || true; rm -rf "$ROOT/.venv" "$STATE/runtime-mode" "$STATE/venv.pid" "$STATE/device-agent.pid" "$STATE/device-agent.sock" "$STATE/ollama.env" "$STATE/ollama-profile" "$STATE/piper.env" "$STATE/piper-profile"
  echo "Project runtime removed. Source/data, Documents/ollama, and Documents/piper-voices remain."
  if [[ "$PURGE_DOCKER" == yes ]]; then if [[ -f "$STATE/docker-installed-by-groot" ]]; then sudo apt-get purge -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin docker-ce-rootless-extras || true; sudo rm -f /etc/apt/sources.list.d/docker.sources /etc/apt/keyrings/docker.asc; rm -f "$STATE/docker-installed-by-groot"; echo "Docker packages removed; Docker data directories were not deleted."; else echo "Refusing Docker removal: no GROOT ownership marker."; fi; fi
  exit 0
fi
if [[ "$ACTION" == status || "$ACTION" == down ]]; then exec "$ROOT/grootctl" "$ACTION"; fi
if [[ "$FRESH_STATE" == yes ]]; then
  "$ROOT/grootctl" down >/dev/null 2>&1 || true
  rm -rf "$ROOT/.groot"
  mkdir -p "$ROOT/.groot/state" "$ROOT/logs" "$ROOT/data" "$ROOT/workspace/sites" "$ROOT/workspace/notes"
  find "$ROOT/logs" -mindepth 1 -maxdepth 1 -type f ! -name '.gitkeep' -delete 2>/dev/null || true
  find "$ROOT/data" -mindepth 1 -maxdepth 1 -type f ! -name 'codex.json' ! -name 'axiom-persona-registry.json' ! -name '.gitkeep' -delete 2>/dev/null || true
  find "$ROOT/workspace/sites" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null || true
  find "$ROOT/workspace/notes" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null || true
  echo "Fresh GROOT v0.19 state created. Ollama models and Piper voices were not touched."
fi
STATE="$ROOT/.groot/state"; mkdir -p "$STATE"
case "$DOCKER_MODE" in
  off) ensure_venv; echo venv > "$STATE/runtime-mode";;
  existing) have_docker || { echo "Docker/Compose is not ready. Use --docker install or --docker off." >&2; exit 2; }; [[ "$DOCKER_GROUP" == add ]] && ensure_group; echo docker > "$STATE/runtime-mode";;
  install) if ! have_docker; then GROOT_STATE_DIR="$STATE" "$ROOT/scripts/docker-install-ubuntu.sh"; fi; [[ "$DOCKER_GROUP" != skip ]] && ensure_group; have_docker || { echo "Docker installation completed but daemon is not reachable." >&2; exit 3; }; echo docker > "$STATE/runtime-mode";;
  auto) if have_docker; then [[ "$DOCKER_GROUP" == add ]] && ensure_group; echo docker > "$STATE/runtime-mode"; else echo "Docker not detected: selecting isolated Python venv mode."; ensure_venv; echo venv > "$STATE/runtime-mode"; fi;;
esac
RUNTIME="$(cat "$STATE/runtime-mode")"
if [[ "$OLLAMA_MODE" == keep ]]; then [[ -f "$STATE/ollama.env" ]] || configure_ollama off; else [[ "$OLLAMA_MODE" != off && "$RUNTIME" != docker && "$OLLAMA_MODE" != external ]] && { echo "Dockerized Ollama requires Docker." >&2; exit 4; }; [[ "$OLLAMA_MODE" == external && "$RUNTIME" == docker && "$OLLAMA_EXTERNAL_URL" == http://127.0.0.1:11434 ]] && OLLAMA_EXTERNAL_URL="http://host.docker.internal:11434"; configure_ollama "$OLLAMA_MODE"; fi
if [[ "$PIPER_MODE" == keep ]]; then [[ -f "$STATE/piper.env" ]] || configure_piper off; else [[ "$PIPER_MODE" != off && "$RUNTIME" != docker ]] && { echo "Dockerized Piper requires Docker." >&2; exit 5; }; configure_piper "$PIPER_MODE"; fi
"$ROOT/grootctl" up
if [[ "$PULL_MODEL" == yes ]]; then [[ -n "$OLLAMA_MODEL_OVERRIDE" ]] || { echo "--pull-model yes requires --ollama-model NAME" >&2; exit 6; }; "$ROOT/grootctl" ai-pull "$OLLAMA_MODEL_OVERRIDE"; "$ROOT/grootctl" ai-warm "$OLLAMA_MODEL_OVERRIDE"; fi
"$ROOT/grootctl" status
cat <<EOF

Controls:
  ./grootctl status             ./grootctl logs
  ./grootctl ai-status          ./grootctl ai-models
  ./grootctl piper-start        ./grootctl piper-status
  ./grootctl device-status      ./grootctl js-overlay
  ./grootctl extension-path     ./grootctl down
Dashboard: http://127.0.0.1:${GROOT_PORT:-8787}
EOF
