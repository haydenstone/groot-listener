# GROOT Family Expedition Chrome Extension — v0.17.0

This Manifest V3 extension is the persistent carrier for the GROOT family AR.

## Why the extension is required for persistent browsing

A JavaScript bookmarklet or injected page script is destroyed when a normal full-page navigation replaces the document, especially across origins. GROOT therefore uses the extension service worker as the durable carrier. After you explicitly grant web access, it watches the bound tab and reinjects the family AR after each completed http/https navigation.

## Setup

1. Start GROOT.
2. Open `chrome://extensions`, enable Developer mode, and choose **Load unpacked**.
3. Select this `chrome-extension` folder.
4. Open the GROOT dashboard in a normal tab and use the extension popup to pair it.
5. Open the Family Navigator and press **GRANT WEB ACCESS** if you want the family to follow cross-origin navigation automatically.
6. Bind the web tab you want to explore and leave **follow navigation** enabled.

## v0.17.0 behavior

- Family avatars are API-discovered, not hardcoded in the extension UI.
- Normal work/family mode uses the family scope. Private adult modes apply relay-side eligibility filtering.
- The main page overlay has full articulated lightweight bodies for humanoid family personas and lightweight bodies for companions.
- DOM elements, APIs, and resources are personified as temporary page characters but remain explicitly labeled as browser-observed representations.
- The expedition trail and findings use ordinary relay HTTP and are not dependent on QUIC/WebTransport.
- The extension never collects cookies, authorization headers, password values, request bodies, or response bodies.

## Always-visible inspect-to-read speaker

The floating `📣 TEXT` button stays visible even when the main AR dock is minimized. Toggle it to enter inspect-text mode. Hovering highlights the current readable block and shows a preview label; clicking reads it aloud without activating the underlying link/button. The inspector follows dynamically injected DOM nodes and open Shadow DOM, including GROOT-injected UI text. Press Escape to leave inspect-text mode. Chromium may reserve Ctrl+Shift+C for DevTools, but if the page receives that key chord GROOT mirrors the same mode.

### Family Builder and pinned reader controls

The AR overlay can pin `🔊` controls to text blocks. Exiting inspect mode does not cancel current playback; the pinned button becomes `⏹` while speaking. The `🏗 BUILD` palette lets the selected persona create draggable, site-persistent houses, apartments, bathrooms, shops, stalls, rides, parks, and workshops.


## v0.17.0 unified overlay
The extension and the local index now use the same GROOT liquid-glass DOM control surface. Open 🌿 MENU for family, browser, tools, visibility, reply voice, theme, and motion settings.
