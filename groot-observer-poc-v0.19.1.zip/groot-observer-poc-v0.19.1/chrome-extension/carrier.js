(()=>{
  if(window.__GROOT_EXTENSION_CARRIER__) return;
  window.__GROOT_EXTENSION_CARRIER__=true;
  const allowed=new Set(['navigate','back','forward','reload','tab-state','set-auto-explore','avatar-home-get','avatar-home-set']);
  window.addEventListener('message',async ev=>{
    if(ev.source!==window) return;
    const m=ev.data||{};
    if(m.source!=='groot-ar-command'||!m.id||!allowed.has(m.command)) return;
    try{
      const payload={type:m.command,...(m.payload||{})};
      const result=await chrome.runtime.sendMessage(payload);
      window.postMessage({source:'groot-carrier-ack',id:m.id,result},'*');
    }catch(e){
      window.postMessage({source:'groot-carrier-ack',id:m.id,result:{ok:false,error:e.message}},'*');
    }
  });
})();
