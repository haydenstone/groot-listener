(()=>{
  if(window.__GROOT_PAGE_HOOK__) return;
  window.__GROOT_PAGE_HOOK__=true;
  const emit=(detail)=>{try{window.postMessage({source:'groot-page-hook',detail},'*')}catch(_){}};
  const abs=u=>{try{return new URL(u,location.href).href}catch(_){return String(u||'')}};
  const originalFetch=window.fetch;
  if(typeof originalFetch==='function') window.fetch=async function(input,init){
    const url=abs(typeof input==='string'?input:input?.url),method=String(init?.method||input?.method||'GET').toUpperCase(),start=performance.now();
    try{const r=await originalFetch.apply(this,arguments);emit({kind:'api',initiator:'fetch',url,method,status:r.status,duration_ms:Math.round(performance.now()-start)});return r}
    catch(e){emit({kind:'api',initiator:'fetch',url,method,status:0,duration_ms:Math.round(performance.now()-start)});throw e}
  };
  const XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(method,url){this.__groot={method:String(method||'GET').toUpperCase(),url:abs(url)};return XO.apply(this,arguments)};
  XMLHttpRequest.prototype.send=function(){const x=this.__groot||{method:'GET',url:''},start=performance.now();this.addEventListener('loadend',()=>emit({kind:'api',initiator:'xmlhttprequest',url:x.url,method:x.method,status:this.status||0,duration_ms:Math.round(performance.now()-start)}),{once:true});return XS.apply(this,arguments)};
})();
