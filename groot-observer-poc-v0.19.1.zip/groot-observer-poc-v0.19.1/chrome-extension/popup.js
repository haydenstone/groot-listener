const $=id=>document.getElementById(id),send=m=>chrome.runtime.sendMessage(m);
async function refresh(){const j=await send({type:'status'});$('origin').value=j.origin||'';$('status').textContent=j.origin?`paired ${j.origin}\nweb access ${j.webAccess?'granted':'active-tab only'}`:'not paired'}
$('pair').onclick=async()=>{const j=await send({type:'pair-current'});$('status').textContent=j.ok?`paired ${j.origin} · relay ${j.version}`:j.error;refresh()};
$('save').onclick=async()=>{const j=await send({type:'set-origin',origin:$('origin').value});$('status').textContent=j.ok?'saved '+j.origin:j.error;refresh()};
$('toggle').onclick=async()=>{const j=await send({type:'toggle'});$('status').textContent=j.ok?'AR toggled on bound tab':j.error};
$('nav').onclick=async()=>{const j=await send({type:'open-navigator'});if(!j.ok)$('status').textContent=j.error;else window.close()};refresh();
