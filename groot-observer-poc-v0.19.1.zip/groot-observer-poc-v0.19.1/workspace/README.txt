GROOT Workspace

This directory is the bounded workspace exposed to the Nautilus-style browser and Swarm Builder.
Website proof-of-concepts are created under sites/<project>/.
Only files inside this workspace are writable through the GROOT file APIs.
