#!/usr/bin/env python3
import glob, json, os, re, select, shutil, socket, socketserver, subprocess, sys, time
from http.server import BaseHTTPRequestHandler
from pathlib import Path

SOCKET_PATH = Path(os.environ.get('GROOT_DEVICE_SOCKET', str(Path(__file__).resolve().parents[1] / '.groot/state/device-agent.sock')))
START = time.time()
MAX_SERIAL_READ = int(os.environ.get('GROOT_SERIAL_READ_MAX', '8192'))
SERIAL_TIMEOUT = float(os.environ.get('GROOT_SERIAL_READ_TIMEOUT', '0.75'))
WORKSPACE = Path(os.environ.get('GROOT_WORKSPACE_DIR', str(Path(__file__).resolve().parents[1] / 'workspace'))).resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)


def read_text(path, default=None, limit=4096):
    try:
        return Path(path).read_text(errors='replace')[:limit].strip()
    except Exception:
        return default


def read_int(path, default=None):
    v = read_text(path)
    try:
        return int(v) if v is not None else default
    except Exception:
        return default


def stable_id(kind, value):
    return f"{kind}:{value}"


def action(action_id, label, params=None):
    return {"id": action_id, "label": label, "params": params or []}


def usb_devices():
    out = []
    base = Path('/sys/bus/usb/devices')
    if not base.exists():
        return out
    for p in sorted(base.iterdir(), key=lambda x: x.name):
        vid = read_text(p / 'idVendor')
        pid = read_text(p / 'idProduct')
        if not vid or not pid:
            continue
        manufacturer = read_text(p / 'manufacturer')
        product = read_text(p / 'product')
        serial = read_text(p / 'serial')
        cls = read_text(p / 'bDeviceClass')
        speed = read_text(p / 'speed')
        driver = None
        try:
            d = p / 'driver'
            if d.exists(): driver = d.resolve().name
        except Exception:
            pass
        out.append({
            "id": stable_id('usb', p.name),
            "transport": "usb",
            "label": product or manufacturer or f"USB {vid}:{pid}",
            "path": str(p),
            "readable": True,
            "metadata": {"vendor_id": vid, "product_id": pid, "manufacturer": manufacturer, "product": product, "serial": serial, "class": cls, "speed_mbps": speed, "driver": driver},
            "actions": [action('observe', 'READ USB METADATA')],
        })
    return out


def serial_devices():
    paths = []
    byid = Path('/dev/serial/by-id')
    if byid.exists():
        for p in sorted(byid.iterdir()):
            try: paths.append((str(p), str(p.resolve())))
            except Exception: pass
    for pattern in ('/dev/ttyUSB*', '/dev/ttyACM*', '/dev/ttyS*'):
        for p in sorted(glob.glob(pattern)):
            if not any(real == p for _, real in paths):
                paths.append((p, p))
    out=[]
    seen=set()
    for display, real in paths:
        if real in seen: continue
        seen.add(real)
        readable = os.access(real, os.R_OK)
        out.append({
            "id": stable_id('serial', real),
            "transport": "serial",
            "label": Path(display).name,
            "path": display,
            "real_path": real,
            "readable": readable,
            "metadata": {"device": real, "alias": display if display != real else None, "readable": readable},
            "actions": [action('observe', 'READ SERIAL BYTES', [{"name":"timeout_s","type":"number","default":SERIAL_TIMEOUT},{"name":"max_bytes","type":"integer","default":MAX_SERIAL_READ}])],
        })
    return out


def net_devices():
    out=[]
    base=Path('/sys/class/net')
    if not base.exists(): return out
    for p in sorted(base.iterdir(), key=lambda x:x.name):
        name=p.name
        if name == 'lo':
            continue
        oper=read_text(p/'operstate')
        mtu=read_int(p/'mtu')
        mac=read_text(p/'address')
        carrier=read_text(p/'carrier')
        bus='virtual'
        device_path=None
        try:
            device_path=str((p/'device').resolve())
            if '/usb' in device_path: bus='usb'
            elif '/pci' in device_path: bus='pci'
        except Exception:
            pass
        out.append({
            "id": stable_id('net', name),
            "transport": "network",
            "subtransport": bus,
            "label": name,
            "path": str(p),
            "readable": True,
            "metadata": {"interface":name,"operstate":oper,"mtu":mtu,"mac":mac,"carrier":carrier,"bus":bus,"device_path":device_path},
            "actions": [action('observe','READ INTERFACE COUNTERS')],
        })
    return out


def adb_devices():
    if not shutil.which('adb'):
        return []
    try:
        cp=subprocess.run(['adb','devices','-l'],capture_output=True,text=True,timeout=4,check=False)
    except Exception:
        return []
    out=[]
    for line in cp.stdout.splitlines()[1:]:
        line=line.strip()
        if not line: continue
        parts=line.split()
        if len(parts)<2: continue
        serial,status=parts[0],parts[1]
        meta={"serial":serial,"status":status}
        for token in parts[2:]:
            if ':' in token:
                k,v=token.split(':',1); meta[k]=v
        acts=[action('observe','READ ANDROID FACTS')] if status=='device' else []
        out.append({"id":stable_id('adb',serial),"transport":"adb","label":meta.get('model') or serial,"path":None,"readable":status=='device',"metadata":meta,"actions":acts})
    return out


def block_devices():
    out=[]
    base=Path('/sys/class/block')
    if not base.exists(): return out
    for p in sorted(base.iterdir(), key=lambda x:x.name):
        name=p.name
        if re.match(r'^(loop|ram|zram|dm-)', name): continue
        removable=read_text(p/'removable') == '1'
        size_sectors=read_int(p/'size',0) or 0
        if not removable: continue
        out.append({
            "id":stable_id('block',name),"transport":"block","label":name,"path":f'/dev/{name}',"readable":True,
            "metadata":{"removable":True,"size_bytes":size_sectors*512,"ro":read_text(p/'ro')=='1'},
            "actions":[action('observe','READ DEVICE METADATA')]
        })
    return out


def all_devices():
    devices = usb_devices()+serial_devices()+net_devices()+adb_devices()+block_devices()
    return sorted(devices,key=lambda d:(d.get('transport',''), d.get('label','')))


def capabilities():
    adapters=[]
    def add(i,label,available,detail): adapters.append({"id":i,"label":label,"available":bool(available),"detail":detail})
    add('usb-sysfs','USB metadata',Path('/sys/bus/usb/devices').exists(),'/sys/bus/usb/devices')
    add('serial-read','Serial read-only observation',bool(serial_devices()),'non-blocking read, no writes')
    add('network-sysfs','Network interface counters',Path('/sys/class/net').exists(),'/sys/class/net')
    add('adb-readonly','Android ADB read-only facts',bool(shutil.which('adb')),'adb discovered on host PATH' if shutil.which('adb') else 'adb not installed')
    add('removable-block','Removable block metadata',Path('/sys/class/block').exists(),'metadata only; no mounts')
    return {"api_version":"1","socket":str(SOCKET_PATH),"adapters":adapters}


def find_device(device_id):
    for d in all_devices():
        if d['id']==device_id: return d
    return None


def observe_net(dev):
    name=dev['metadata']['interface']; base=Path('/sys/class/net')/name
    stats={}
    sdir=base/'statistics'
    if sdir.exists():
        for p in sorted(sdir.iterdir()):
            v=read_text(p)
            if v is not None:
                try: stats[p.name]=int(v)
                except Exception: stats[p.name]=v
    addresses=[]
    if shutil.which('ip'):
        try:
            cp=subprocess.run(['ip','-j','addr','show','dev',name],capture_output=True,text=True,timeout=3,check=False)
            if cp.stdout.strip(): addresses=json.loads(cp.stdout)
        except Exception: pass
    return {"device":dev,"observation":{"statistics":stats,"addresses":addresses,"observed_at":time.time()}}


def observe_usb(dev):
    path=Path(dev['path'])
    fields={}
    for name in ('idVendor','idProduct','manufacturer','product','serial','bDeviceClass','bDeviceSubClass','bDeviceProtocol','speed','busnum','devnum','version'):
        v=read_text(path/name)
        if v is not None: fields[name]=v
    interfaces=[]
    for child in sorted(path.parent.glob(path.name+':*')):
        driver=None
        try:
            if (child/'driver').exists(): driver=(child/'driver').resolve().name
        except Exception: pass
        interfaces.append({"name":child.name,"class":read_text(child/'bInterfaceClass'),"subclass":read_text(child/'bInterfaceSubClass'),"protocol":read_text(child/'bInterfaceProtocol'),"driver":driver})
    return {"device":dev,"observation":{"fields":fields,"interfaces":interfaces,"observed_at":time.time()}}


def observe_serial(dev, params):
    path=dev.get('real_path') or dev.get('path')
    if not path or not os.path.exists(path): raise FileNotFoundError(path or 'serial device')
    timeout=max(0.05,min(float(params.get('timeout_s',SERIAL_TIMEOUT)),5.0))
    max_bytes=max(1,min(int(params.get('max_bytes',MAX_SERIAL_READ)),65536))
    flags=os.O_RDONLY|os.O_NONBLOCK
    if hasattr(os,'O_NOCTTY'): flags|=os.O_NOCTTY
    fd=os.open(path,flags)
    try:
        ready,_,_=select.select([fd],[],[],timeout)
        data=os.read(fd,max_bytes) if ready else b''
    finally:
        os.close(fd)
    return {"device":dev,"observation":{"bytes":len(data),"text":data.decode('utf-8','replace'),"hex":data[:2048].hex(),"truncated_hex":len(data)>2048,"observed_at":time.time()}}


def observe_adb(dev):
    serial=dev['metadata']['serial']
    cmds={
        'uname':['uname','-a'],
        'uptime':['cat','/proc/uptime'],
        'manufacturer':['getprop','ro.product.manufacturer'],
        'model':['getprop','ro.product.model'],
        'device':['getprop','ro.product.device'],
        'android_release':['getprop','ro.build.version.release'],
        'sdk':['getprop','ro.build.version.sdk'],
        'meminfo':['sh','-c','head -n 12 /proc/meminfo'],
    }
    obs={}
    for key,cmd in cmds.items():
        try:
            cp=subprocess.run(['adb','-s',serial,'shell',*cmd],capture_output=True,text=True,timeout=4,check=False)
            obs[key]=cp.stdout.strip() if cp.returncode==0 else {"error":cp.stderr.strip(),"returncode":cp.returncode}
        except Exception as e: obs[key]={"error":str(e)}
    obs['observed_at']=time.time()
    return {"device":dev,"observation":obs}


def observe_block(dev):
    name=Path(dev['path']).name; base=Path('/sys/class/block')/name
    data={"size_bytes":(read_int(base/'size',0) or 0)*512,"removable":read_text(base/'removable')=='1','read_only':read_text(base/'ro')=='1','observed_at':time.time()}
    return {"device":dev,"observation":data}


def observe(device_id, params=None):
    dev=find_device(device_id)
    if not dev: raise KeyError(f'device not found: {device_id}')
    t=dev['transport']; params=params or {}
    if t=='network': return observe_net(dev)
    if t=='usb': return observe_usb(dev)
    if t=='serial': return observe_serial(dev,params)
    if t=='adb': return observe_adb(dev)
    if t=='block': return observe_block(dev)
    raise ValueError(f'unsupported transport: {t}')



def _target_host(value):
    value=str(value or '').strip()
    if not value: raise ValueError('target required')
    if '://' in value:
        from urllib.parse import urlparse
        value=urlparse(value).hostname or ''
    value=value.strip('[]')
    if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,253}', value):
        raise ValueError('invalid hostname or IP target')
    return value

def path_capabilities():
    return {
        'tracepath': bool(shutil.which('tracepath')),
        'traceroute': bool(shutil.which('traceroute')),
        'ip': bool(shutil.which('ip')),
        'getent': bool(shutil.which('getent')),
        'note': 'Path discovery reports only hops that answer the selected trace method. Some routers intentionally remain silent.'
    }

def trace_path(target):
    host=_target_host(target)
    started=time.time(); resolved=[]
    try:
        for fam,_,_,_,addr in socket.getaddrinfo(host,None):
            ip=addr[0]
            if ip not in resolved: resolved.append(ip)
    except Exception as e:
        return {'target':host,'resolved':[],'hops':[],'error':f'DNS resolution failed: {e}','observed_at':time.time()}
    route=None
    if shutil.which('ip'):
        try:
            cp=subprocess.run(['ip','route','get',resolved[0]],capture_output=True,text=True,timeout=4,check=False)
            route=cp.stdout.strip() or cp.stderr.strip()
        except Exception as e: route=str(e)
    cmd=None; method=None
    if shutil.which('tracepath'):
        cmd=['tracepath','-n','-m','24',host]; method='tracepath'
    elif shutil.which('traceroute'):
        cmd=['traceroute','-n','-w','1','-q','1','-m','24',host]; method='traceroute'
    hops=[]; raw=''; err=None
    if cmd:
        try:
            cp=subprocess.run(cmd,capture_output=True,text=True,timeout=35,check=False)
            raw=(cp.stdout+'\n'+cp.stderr).strip()[:24000]
            for line in cp.stdout.splitlines():
                m=re.match(r'\s*(\d+)[?:]?\s+([^\s]+)(?:\s+.*?([0-9.]+)\s*ms)?',line)
                if not m: continue
                token=m.group(2); latency=None
                lm=re.findall(r'([0-9.]+)\s*ms',line)
                if lm:
                    try: latency=float(lm[-1])
                    except Exception: pass
                hops.append({'hop':int(m.group(1)),'address':None if token in ('*','no','resume') else token,'latency_ms':latency,'raw':line.strip()[:400]})
        except subprocess.TimeoutExpired:
            err='trace timed out after 35 seconds'
        except Exception as e: err=str(e)
    else:
        err='tracepath/traceroute is not installed on the host'
    return {'target':host,'resolved':resolved[:8],'route':route,'method':method,'hops':hops,'raw':raw,'error':err,'duration_ms':round((time.time()-started)*1000,1),'observed_at':time.time(),'complete':bool(hops and hops[-1].get('address') in resolved),'note':'Silent or filtered hops may appear as unknown; this is observed path evidence, not proof of every physical node.'}

def _docker_available():
    return bool(shutil.which('docker'))

def _docker_json_lines(args, timeout=8):
    cp=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=timeout,check=False)
    if cp.returncode!=0: raise RuntimeError(cp.stderr.strip() or cp.stdout.strip() or 'docker command failed')
    out=[]
    for line in cp.stdout.splitlines():
        line=line.strip()
        if not line: continue
        try: out.append(json.loads(line))
        except Exception: out.append({'raw':line})
    return out

def docker_pocs():
    if not _docker_available(): return {'available':False,'containers':[],'error':'docker CLI not installed'}
    try:
        rows=_docker_json_lines(['ps','-a','--filter','label=groot.poc=true','--format','{{json .}}'])
        return {'available':True,'containers':rows}
    except Exception as e: return {'available':False,'containers':[],'error':str(e)}

def _site_dir(slug):
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,40}',slug or ''): raise ValueError('slug must be lowercase letters, digits, and hyphens')
    p=(WORKSPACE/'sites'/slug).resolve()
    base=(WORKSPACE/'sites').resolve()
    if p!=base and base not in p.parents: raise ValueError('site path escaped workspace')
    return p

def docker_spin(slug):
    if not _docker_available(): raise RuntimeError('docker CLI not installed')
    site=_site_dir(slug)
    if not (site/'index.html').is_file(): raise FileNotFoundError(f'{site}/index.html')
    name='groot-poc-'+slug
    check=subprocess.run(['docker','inspect',name],capture_output=True,text=True,timeout=5,check=False)
    if check.returncode==0: raise RuntimeError(f'container already exists: {name}')
    cp=subprocess.run(['docker','run','-d','--label','groot.poc=true','--label',f'groot.project={slug}','--name',name,'-p','127.0.0.1::80','-v',f'{site}:/usr/share/nginx/html:ro','nginx:alpine'],capture_output=True,text=True,timeout=90,check=False)
    if cp.returncode!=0: raise RuntimeError(cp.stderr.strip() or 'docker run failed')
    ins=subprocess.run(['docker','port',name,'80/tcp'],capture_output=True,text=True,timeout=5,check=False)
    port=None
    m=re.search(r':(\d+)\s*$',ins.stdout.strip())
    if m: port=int(m.group(1))
    return {'name':name,'project':slug,'container_id':cp.stdout.strip(),'url':f'http://127.0.0.1:{port}' if port else None,'site_dir':str(site)}

def _managed_container(name):
    if not re.fullmatch(r'groot-poc-[a-z0-9][a-z0-9-]{0,40}',name or ''): return False
    cp=subprocess.run(['docker','inspect','-f','{{ index .Config.Labels "groot.poc" }}',name],capture_output=True,text=True,timeout=5,check=False)
    return cp.returncode==0 and cp.stdout.strip()=='true'

def docker_action(name, action_name):
    if not _managed_container(name): raise PermissionError('container is not a GROOT-managed proof-of-concept')
    if action_name=='logs':
        cp=subprocess.run(['docker','logs','--tail','120',name],capture_output=True,text=True,timeout=8,check=False)
        return {'name':name,'action':'logs','text':(cp.stdout+cp.stderr)[-20000:]}
    if action_name not in ('start','stop','restart','rm'): raise ValueError('unsupported action')
    args=['docker',action_name]
    if action_name=='rm': args.append('-f')
    args.append(name)
    cp=subprocess.run(args,capture_output=True,text=True,timeout=30,check=False)
    if cp.returncode!=0: raise RuntimeError(cp.stderr.strip() or 'docker action failed')
    return {'name':name,'action':action_name,'result':cp.stdout.strip(),'containers':docker_pocs().get('containers',[])}

class Handler(BaseHTTPRequestHandler):
    server_version='GROOTDeviceAgent/0.19.1'
    def log_message(self, fmt, *args):
        print('DEVICE', fmt%args, flush=True)
    def send_json(self,obj,status=200):
        raw=json.dumps(obj,default=str).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path=='/api/health': return self.send_json({"ok":True,"version":"0.19.1","uptime_s":int(time.time()-START)})
        if self.path=='/api/capabilities': return self.send_json(capabilities())
        if self.path=='/api/devices':
            ds=all_devices(); return self.send_json({"devices":ds,"count":len(ds),"transports":sorted({d['transport'] for d in ds})})
        if self.path=='/api/path/capabilities': return self.send_json(path_capabilities())
        if self.path=='/api/docker': return self.send_json(docker_pocs())
        return self.send_json({"error":"not found"},404)
    def do_POST(self):
        try:
            n=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(n) or b'{}')
            if self.path=='/api/observe':
                did=str(body.get('id','')); params=body.get('params') if isinstance(body.get('params'),dict) else {}
                if not did: return self.send_json({"error":"id required"},400)
                return self.send_json(observe(did,params))
            if self.path=='/api/path/trace': return self.send_json(trace_path(body.get('target')))
            if self.path=='/api/docker/spin': return self.send_json(docker_spin(str(body.get('slug','')).strip()))
            if self.path=='/api/docker/action': return self.send_json(docker_action(str(body.get('name','')),str(body.get('action',''))))
            return self.send_json({"error":"not found"},404)
        except PermissionError as e: return self.send_json({"error":str(e),"hint":"operation is restricted to read-only devices or GROOT-managed POC containers"},403)
        except FileNotFoundError as e: return self.send_json({"error":str(e)},404)
        except KeyError as e: return self.send_json({"error":str(e)},404)
        except ValueError as e: return self.send_json({"error":str(e)},400)
        except Exception as e: return self.send_json({"error":str(e)},500)

class ThreadingUnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads=True
    allow_reuse_address=True

if __name__=='__main__':
    SOCKET_PATH.parent.mkdir(parents=True,exist_ok=True)
    try: SOCKET_PATH.unlink()
    except FileNotFoundError: pass
    server=ThreadingUnixServer(str(SOCKET_PATH),Handler)
    os.chmod(SOCKET_PATH,0o660)
    print(f'GROOT device agent v0.19.1 listening on unix://{SOCKET_PATH}',flush=True)
    try: server.serve_forever()
    finally:
        try: SOCKET_PATH.unlink()
        except Exception: pass
