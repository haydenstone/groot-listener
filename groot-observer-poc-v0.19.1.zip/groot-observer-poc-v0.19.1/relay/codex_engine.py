#!/usr/bin/env python3
import json,re,time,random
from pathlib import Path
from collections import Counter

STOP=set('a an and are as at be been but by can could did do does for from had has have he her him his i if in into is it its me my no nor not of on or our she so than that the their them then there these they this to too us was we were what when where which who why will with you your'.split())
TOK=re.compile(r"[A-Za-z][A-Za-z'’-]{2,}")
REF_RE=re.compile(r"\b((?:[1-3]\s*)?[A-Za-z]+(?:\s+[A-Za-z]+)*)\s+(\d{1,3})\s*:\s*(\d{1,3})(?:\s*[-–]\s*(\d{1,3}))?\b")

class Codex:
    def __init__(self,path):
        self.path=Path(path); self.translation=None; self.books={}; self.verses=[]; self.loaded=False; self.error=None
        self._load()
    def _load(self):
        if not self.path.exists():
            self.error=f"not found: {self.path}"; return
        try:
            text=self.path.read_text(encoding="utf-8",errors="replace")
            tm=re.search(r'"Translation"\s*:\s*"([^"]+)"',text)
            if tm: self.translation=tm.group(1)
            dec=json.JSONDecoder(); seen=set()
            # The supplied codex is a concatenation of per-book JSON fragments and
            # contains a few malformed outer boundaries. Parse each book value
            # independently so one broken wrapper cannot discard the corpus.
            for m in re.finditer(r'(?m)^\s{2}"([^"]+)"\s*:\s*\{',text):
                book=m.group(1)
                if book=="Info" or book in seen: continue
                brace=text.find("{",m.start())
                try: val,_=dec.raw_decode(text,brace)
                except Exception: continue
                if not isinstance(val,dict): continue
                # A Bible-book value is chapters -> verses -> strings.
                if not any(isinstance(v,dict) for v in val.values()): continue
                seen.add(book); self.books[book]=val
                for ch,verses in val.items():
                    if not isinstance(verses,dict): continue
                    for vs,body in verses.items():
                        if isinstance(body,str): self.verses.append((book,str(ch),str(vs),body))
            self.loaded=bool(self.verses)
            self.error=None if self.loaded else "no verse corpus discovered"
        except Exception as e:
            self.error=str(e)
    def status(self):
        return {'online':self.loaded,'path':str(self.path),'translation':self.translation,'books':len(self.books),'verses':len(self.verses),'error':self.error}
    def lookup(self,book,chapter,verse,end=None):
        chapters=self.books.get(book)
        if not isinstance(chapters,dict): return []
        vv=chapters.get(str(chapter));
        if not isinstance(vv,dict): return []
        a=int(verse); b=int(end or verse); out=[]
        for i in range(a,b+1):
            body=vv.get(str(i))
            if isinstance(body,str): out.append({'ref':f'{book} {chapter}:{i}','text':body})
        return out
    def references(self,text,limit=6):
        out=[]
        for m in REF_RE.finditer(text or ''):
            book=' '.join(m.group(1).split()); hits=self.lookup(book,m.group(2),m.group(3),m.group(4)); out.extend(hits)
            if len(out)>=limit: break
        return out[:limit]
    def roll(self, persona_ids, exclude_refs=None, seed=None):
        """Assign one unique, varied verse to each persona without hardcoded references.

        Variety is maximized across books first, then across individual references.
        exclude_refs can carry recent client/server history so successive rolls do not
        immediately recycle the same passages.
        """
        ids=[]
        for raw in (persona_ids or []):
            pid=str(raw).strip()
            if pid and pid not in ids:
                ids.append(pid)
        if not self.loaded or not ids:
            return []
        exclude={str(x) for x in (exclude_refs or []) if x}
        rng=random.Random(str(seed) if seed is not None else f"{time.time_ns()}:{len(ids)}")
        by_book={}
        for book,ch,vs,body in self.verses:
            ref=f'{book} {ch}:{vs}'
            if ref in exclude or not str(body).strip():
                continue
            by_book.setdefault(book,[]).append((ch,vs,body,ref))
        # If a client excludes nearly the whole corpus, gracefully reopen the pool.
        if not by_book:
            for book,ch,vs,body in self.verses:
                if str(body).strip():
                    ref=f'{book} {ch}:{vs}'
                    by_book.setdefault(book,[]).append((ch,vs,body,ref))
        books=list(by_book)
        rng.shuffle(books)
        used=set(); out=[]; book_cursor=0
        for pid in ids:
            chosen=None
            # Prefer a different book for every reader while enough books remain.
            for _ in range(max(1,len(books))):
                if not books: break
                book=books[book_cursor % len(books)]; book_cursor += 1
                pool=[x for x in by_book.get(book,[]) if x[3] not in used]
                if not pool: continue
                chosen=(book,rng.choice(pool)); break
            if chosen is None:
                pool=[]
                for book,rows in by_book.items():
                    pool.extend((book,x) for x in rows if x[3] not in used)
                if not pool: break
                chosen=rng.choice(pool)
            book,(ch,vs,body,ref)=chosen
            used.add(ref)
            out.append({'persona_id':pid,'ref':ref,'text':body,'book':book,'chapter':str(ch),'verse':str(vs),'translation':self.translation})
        return out

    def resonance(self,text,limit=3):
        if not self.loaded: return []
        direct=self.references(text,limit)
        if direct: return direct[:limit]
        toks=[t.lower().replace('’',"'") for t in TOK.findall(text or '')]
        q=Counter(t for t in toks if t not in STOP)
        if not q: return []
        terms=set(q)
        scored=[]
        for book,ch,vs,body in self.verses:
            bt=[t.lower().replace('’',"'") for t in TOK.findall(body)]
            overlap=Counter(bt)
            score=sum((1+min(3,q[t]))*(1+min(2,overlap[t])) for t in terms if overlap[t])
            if score: scored.append((score,book,ch,vs,body))
        scored.sort(key=lambda x:(-x[0],x[1],int(x[2]),int(x[3])))
        out=[]; seen_books=Counter()
        for score,book,ch,vs,body in scored:
            if seen_books[book]>=2: continue
            out.append({'ref':f'{book} {ch}:{vs}','text':body,'score':score}); seen_books[book]+=1
            if len(out)>=limit: break
        return out
