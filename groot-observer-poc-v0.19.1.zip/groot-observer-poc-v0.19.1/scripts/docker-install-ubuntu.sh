#!/usr/bin/env bash
set -Eeuo pipefail
STATE_DIR="${GROOT_STATE_DIR:-$(pwd)/.groot/state}"
mkdir -p "$STATE_DIR"
if ! command -v apt-get >/dev/null 2>&1; then echo "This installer currently supports Ubuntu/Debian apt hosts only." >&2; exit 2; fi
. /etc/os-release
if [[ "${ID:-}" != "ubuntu" ]]; then echo "Automatic Docker install is intentionally limited to Ubuntu. Detected: ${ID:-unknown}." >&2; exit 2; fi
command -v sudo >/dev/null || { echo "sudo is required for Docker host installation." >&2; exit 2; }
echo "Installing Docker Engine from Docker's official apt repository for Ubuntu ${VERSION_ID:-unknown} (${VERSION_CODENAME:-unknown})."
sudo apt-get update
sudo apt-get install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
ARCH="$(dpkg --print-architecture)"; CODENAME="${UBUNTU_CODENAME:-${VERSION_CODENAME}}"
sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: ${CODENAME}
Components: stable
Architectures: ${ARCH}
Signed-By: /etc/apt/keyrings/docker.asc
EOF
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker run --rm hello-world >/dev/null
printf '%s\n' "installed_at=$(date -Is)" "host_id=${ID}" "host_version=${VERSION_ID:-}" > "$STATE_DIR/docker-installed-by-groot"
echo "Docker installed and verified."
