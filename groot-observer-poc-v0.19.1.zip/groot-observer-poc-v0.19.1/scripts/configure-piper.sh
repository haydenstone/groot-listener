#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="${GROOT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
STATE="${GROOT_STATE_DIR:-$ROOT/.groot/state}"
mkdir -p "$STATE"
MODE="${1:-off}"
TARGET_USER="${SUDO_USER:-${USER:-$(id -un)}}"
TARGET_HOME="$(getent passwd "$TARGET_USER" 2>/dev/null | awk -F: '{print $6}' | head -1)"
[[ -n "$TARGET_HOME" ]] || TARGET_HOME="$HOME"
DATA_DIR="${PIPER_DATA_DIR_OVERRIDE:-${PIPER_DATA_DIR:-$TARGET_HOME/Documents/piper-voices}}"
mkdir -p "$DATA_DIR"
case "$MODE" in
  off) PROFILE=off ;;
  on|safe|8gb) PROFILE=8gb-piper ;;
  *) echo "Invalid Piper mode: $MODE" >&2; exit 2 ;;
esac
cat > "$STATE/piper.env" <<ENV
GROOT_PIPER_PROFILE=$PROFILE
PIPER_URL=http://piper:5000
PIPER_PORT=5000
PIPER_MEMORY_LIMIT=768m
PIPER_CPUS=1.5
PIPER_CACHE_SIZE=2
PIPER_MAX_TEXT=900
PIPER_DATA_DIR=$DATA_DIR
ENV
echo "$PROFILE" > "$STATE/piper-profile"
printf 'piper_profile=%s\npiper_memory_limit=768m\npiper_cpus=1.5\npiper_voice_cache=2\npiper_data_dir=%s\n' "$PROFILE" "$DATA_DIR"
