#!/usr/bin/env bash
set -Eeuo pipefail

MODE="${1:-add}"
[[ "$MODE" =~ ^(add|check)$ ]] || { echo "Usage: $0 {add|check}" >&2; exit 2; }
TARGET_USER="${GROOT_TARGET_USER:-${SUDO_USER:-${USER:-$(id -un)}}}"

say(){ printf '[groot:docker-group] %s\n' "$*"; }
die(){ printf '[groot:docker-group] ERROR: %s\n' "$*" >&2; exit 2; }

if [[ -z "$TARGET_USER" || "$TARGET_USER" == "root" ]]; then
  say "Invoking user is root; docker-group membership is not required."
  exit 0
fi
id "$TARGET_USER" >/dev/null 2>&1 || die "User '$TARGET_USER' does not exist."

if id -nG "$TARGET_USER" | tr ' ' '\n' | grep -qx docker; then
  say "$TARGET_USER is already a member of docker."
  exit 0
fi

if [[ "$MODE" == "check" ]]; then
  say "$TARGET_USER is NOT currently a member of docker."
  exit 1
fi

command -v sudo >/dev/null 2>&1 || die "sudo is required to add $TARGET_USER to the docker group."
say "Adding $TARGET_USER to the docker group."
sudo groupadd -f docker
sudo usermod -aG docker "$TARGET_USER"

if id -nG "$TARGET_USER" | tr ' ' '\n' | grep -qx docker; then
  say "$TARGET_USER has been added to docker."
  say "Existing login sessions keep their old group list. Log out/in, reboot, or run 'newgrp docker' in a terminal to activate direct Docker access."
  say "Until then, GROOT can still use sudo docker automatically."
else
  die "usermod returned, but docker membership could not be verified."
fi
