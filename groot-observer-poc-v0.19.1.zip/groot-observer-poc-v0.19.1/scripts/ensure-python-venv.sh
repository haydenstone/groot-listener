#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${GROOT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
STATE="${GROOT_STATE_DIR:-$ROOT/.groot/state}"
mkdir -p "$STATE"

say(){ printf '[groot:venv] %s\n' "$*"; }
die(){ printf '[groot:venv] ERROR: %s\n' "$*" >&2; exit 2; }

command -v python3 >/dev/null 2>&1 || die "python3 is required."
PYVER="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
PROBE="$STATE/.venv-probe-$$"
ERR="$STATE/venv-probe.err"

cleanup(){ rm -rf "$PROBE"; }
trap cleanup EXIT

probe(){
  rm -rf "$PROBE"
  : > "$ERR"
  if python3 -m venv "$PROBE" >/dev/null 2>"$ERR"; then
    [[ -x "$PROBE/bin/python" ]] || return 1
    "$PROBE/bin/python" -c 'import sys; assert sys.prefix != sys.base_prefix' >/dev/null 2>&1 || return 1
    rm -rf "$PROBE"
    return 0
  fi
  rm -rf "$PROBE"
  return 1
}

if probe; then
  say "Python $PYVER venv support is ready."
  exit 0
fi

say "Python $PYVER cannot currently create a complete virtual environment."
[[ -s "$ERR" ]] && sed 's/^/[groot:venv]   /' "$ERR" >&2 || true

if ! command -v apt-get >/dev/null 2>&1; then
  die "Automatic repair currently supports apt-based Debian/Ubuntu hosts. Install the venv package for Python $PYVER, then rerun."
fi
command -v sudo >/dev/null 2>&1 || die "sudo is required to install the missing venv package."

EXACT="python${PYVER}-venv"
FALLBACK="python3-venv"
say "Repairing venv support with apt (preferred package: $EXACT)."
sudo apt-get update
if apt-cache show "$EXACT" >/dev/null 2>&1; then
  sudo apt-get install -y "$EXACT"
else
  say "$EXACT is not available from configured repositories; trying $FALLBACK."
  sudo apt-get install -y "$FALLBACK"
fi

probe || {
  [[ -s "$ERR" ]] && sed 's/^/[groot:venv]   /' "$ERR" >&2 || true
  die "venv repair completed, but Python $PYVER still cannot create a venv."
}

say "venv support repaired successfully."
