#!/usr/bin/env python3
import io, json, os, re, subprocess, threading, time, wave
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

try:
    from piper import PiperVoice
except ImportError:
    from piper.voice import PiperVoice

PORT=int(os.getenv('PIPER_PORT','5000'))
VOICE_DIR=Path('/voices')
CACHE_SIZE=max(1,int(os.getenv('PIPER_CACHE_SIZE','2')))
MAX_TEXT=max(64,int(os.getenv('PIPER_MAX_TEXT','900')))
CACHE=OrderedDict(); LOCK=threading.Lock(); START=time.time(); CATALOG={"ts":0,"voices":[]}
VOICE_RE=re.compile(r'^[A-Za-z0-9_.-]+$')

def installed_voices():
    out=[]
    for model in sorted(VOICE_DIR.glob('*.onnx')):
        name=model.stem
        if (VOICE_DIR/f'{name}.onnx.json').exists(): out.append(name)
    return out

def catalog_voices(force=False):
    now=time.time()
    if CATALOG['voices'] and not force and now-CATALOG['ts']<900: return CATALOG['voices']
    try:
        cp=subprocess.run(['python','-m','piper.download_voices'],capture_output=True,text=True,timeout=30,check=False)
        names=[]
        for line in (cp.stdout+'\n'+cp.stderr).splitlines():
            s=line.strip().split()[0] if line.strip() else ''
            if VOICE_RE.match(s) and '_' in s and '-' in s: names.append(s)
        names=sorted(set(names)); CATALOG.update(ts=now,voices=names); return names
    except Exception: return CATALOG['voices']

def install_voice(name):
    if not VOICE_RE.match(name): raise ValueError('invalid voice name')
    cp=subprocess.run(['python','-m','piper.download_voices','--data-dir',str(VOICE_DIR),name],capture_output=True,text=True,timeout=600,check=False)
    if cp.returncode!=0: raise RuntimeError((cp.stderr or cp.stdout or 'voice download failed')[-4000:])
    if name not in installed_voices(): raise RuntimeError('download completed but voice files were not found')
    return name

def get_voice(name=None):
    voices=installed_voices()
    if not voices: raise FileNotFoundError('no Piper voices installed')
    if not name: name=voices[0]
    if name not in voices: raise FileNotFoundError(f'voice not installed: {name}')
    with LOCK:
        if name in CACHE:
            voice=CACHE.pop(name); CACHE[name]=voice; return voice,name
        path=VOICE_DIR/f'{name}.onnx'; cfg=VOICE_DIR/f'{name}.onnx.json'
        voice=PiperVoice.load(str(path),config_path=str(cfg)); CACHE[name]=voice
        while len(CACHE)>CACHE_SIZE: CACHE.popitem(last=False)
        return voice,name

def synthesize(text,voice_name=None):
    text=' '.join(str(text).split())[:MAX_TEXT]
    if not text: raise ValueError('text required')
    voice,used=get_voice(voice_name); buf=io.BytesIO()
    with wave.open(buf,'wb') as wav_file: voice.synthesize_wav(text,wav_file)
    return buf.getvalue(),used

class Handler(BaseHTTPRequestHandler):
    server_version='GROOTPiper/0.8.0'
    def log_message(self,fmt,*args): print('PIPER',fmt%args,flush=True)
    def send_json(self,obj,status=200):
        raw=json.dumps(obj).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def read_json(self):
        n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or b'{}')
    def do_GET(self):
        if self.path=='/health': return self.send_json({'ok':True,'version':'0.8.0','voices':installed_voices(),'cached':list(CACHE),'uptime_s':int(time.time()-START)})
        if self.path=='/voices': return self.send_json({'voices':installed_voices(),'cached':list(CACHE),'cache_size':CACHE_SIZE})
        if self.path=='/catalog': return self.send_json({'voices':catalog_voices()})
        return self.send_json({'error':'not found'},404)
    def do_POST(self):
        try: body=self.read_json()
        except Exception: return self.send_json({'error':'invalid json'},400)
        if self.path=='/install':
            try: return self.send_json({'installed':install_voice(str(body.get('voice','')).strip()),'voices':installed_voices()})
            except Exception as e: return self.send_json({'error':str(e)},500)
        if self.path!='/synthesize': return self.send_json({'error':'not found'},404)
        try:
            started=time.monotonic(); wav,used=synthesize(body.get('text',''),body.get('voice')); elapsed=round((time.monotonic()-started)*1000,1)
            self.send_response(200); self.send_header('Content-Type','audio/wav'); self.send_header('X-GROOT-Voice',used); self.send_header('X-GROOT-Synthesis-MS',str(elapsed)); self.send_header('Content-Length',str(len(wav))); self.end_headers(); self.wfile.write(wav)
        except Exception as e: return self.send_json({'error':str(e)},500)

if __name__=='__main__':
    VOICE_DIR.mkdir(parents=True,exist_ok=True)
    print(f'GROOT Piper v0.8.0 listening on 0.0.0.0:{PORT}; installed={len(installed_voices())}; cache={CACHE_SIZE}',flush=True)
    ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
