#!/usr/bin/env bash
set -Eeuo pipefail
mkdir -p /voices
exec python /srv/server.py
