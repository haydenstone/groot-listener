#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
log(){ printf '[groot-compose] %s\n' "$*"; }
die(){ printf '[groot-compose] ERROR: %s\n' "$*" >&2; exit 1; }

command -v docker >/dev/null 2>&1 || die "Docker is required. Install Docker Engine/Desktop, then rerun."
docker info >/dev/null 2>&1 || die "Docker daemon is not reachable by this user."
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 plugin is required ('docker compose')."

[ -f .env ] || { cp .env.example .env; log "Created .env from .env.example"; }
set -a; . ./.env; set +a
mkdir -p runtime config data

log "Validating Compose configuration."
docker compose config >/dev/null
log "Building GROOT Observer image."
docker compose build groot-observer
log "Compose build complete."
printf '\nStart:   ./scripts/start.sh\nStatus:  ./scripts/status.sh\nLogs:    ./scripts/logs.sh\nConfig:  ./scripts/compose-config.sh\nSpeech:  ./scripts/start-speech.sh\nFull:    ./scripts/start-full.sh\nRepair:  ./scripts/repair.sh\nUI:      http://127.0.0.1:%s\n\n' "${GROOT_PORT:-8787}"
