#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[ -f .env ] && set -a && . ./.env && set +a
PURGE=false
[ "${1:-}" = "--purge" ] && PURGE=true

echo '[groot-compose] Stopping/removing GROOT services, including optional speech/Ollama profiles.'
docker compose --profile speech --profile ollama down --remove-orphans || true

if $PURGE; then
  echo '[groot-compose] PURGE: removing local GROOT images, runtime database, speech model cache and Ollama data.'
  docker image rm "${GROOT_IMAGE:-groot-observer:0.26.0}" 2>/dev/null || true
  docker image rm "${GROOT_SPEECH_IMAGE:-groot-speech:0.26.0}" 2>/dev/null || true
  rm -f runtime/groot.db runtime/groot.db-shm runtime/groot.db-wal
  docker volume rm "${GROOT_SPEECH_VOLUME:-groot-speech-models}" 2>/dev/null || true
  docker volume rm "${OLLAMA_VOLUME:-groot-ollama-data}" 2>/dev/null || true
else
  echo '[groot-compose] Source, config, codex, runtime database, images and model data were preserved.'
  echo 'Use ./scripts/uninstall.sh --purge for the destructive GROOT-only cleanup path.'
fi
