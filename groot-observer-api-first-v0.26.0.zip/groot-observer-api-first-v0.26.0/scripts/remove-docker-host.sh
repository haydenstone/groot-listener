#!/usr/bin/env bash
set -Eeuo pipefail

cat <<'MSG'
This removes Docker packages from the HOST, not just GROOT.
It can affect every Docker project on this computer.

Default behavior removes packages only and leaves /var/lib/docker intact.
To also destroy ALL Docker images, containers, volumes and engine data, pass:
  --purge-all-docker-data
MSG

PURGE_DATA=false
[ "${1:-}" = "--purge-all-docker-data" ] && PURGE_DATA=true

[ -r /etc/os-release ] || { echo "Unsupported host" >&2; exit 1; }
. /etc/os-release
case " ${ID:-} ${ID_LIKE:-} " in *debian*|*ubuntu*) ;; *) echo "Debian/Ubuntu only" >&2; exit 1;; esac
SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO=sudo

if command -v systemctl >/dev/null 2>&1; then $SUDO systemctl stop docker 2>/dev/null || true; fi
$SUDO apt-get remove -y docker.io docker-compose-v2 docker-compose-plugin containerd runc 2>/dev/null || true
$SUDO apt-get autoremove -y || true

if $PURGE_DATA; then
  echo "PURGE requested: deleting /var/lib/docker and /var/lib/containerd."
  $SUDO rm -rf /var/lib/docker /var/lib/containerd
else
  echo "Docker engine data preserved under /var/lib/docker and /var/lib/containerd."
fi
