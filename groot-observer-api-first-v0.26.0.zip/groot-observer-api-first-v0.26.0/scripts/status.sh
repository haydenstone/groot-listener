#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[ -f .env ] && set -a && . ./.env && set +a
PORT="${GROOT_PORT:-8787}"
printf 'GROOT Observer %s\n' "$(cat VERSION 2>/dev/null || echo unknown)"
if ! command -v docker >/dev/null 2>&1; then
  echo 'WARN  docker missing'; exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo 'WARN  docker compose v2 missing'; exit 1
fi
printf '\n-- compose --\n'
docker compose ps 2>/dev/null || true
printf '\n-- API --\n'
if curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/v1/health" 2>/dev/null; then
  printf '\nOK    API responding on 127.0.0.1:%s\n' "$PORT"
else
  echo 'WARN  API not responding'
fi
printf '\n-- in-container signal tooling --\n'
docker compose exec -T groot-observer sh -lc '
for cmd in ip lsusb udevadm nmcli bluetoothctl v4l2-ctl ffmpeg arecord espeak-ng ssh lldpctl; do
  if command -v "$cmd" >/dev/null 2>&1; then echo "OK    $cmd"; else echo "WARN  $cmd missing"; fi
done
printf "devices: "; ls /dev/ttyUSB* /dev/ttyACM* /dev/video* 2>/dev/null | tr "\n" " " || true; echo
' 2>/dev/null || echo 'WARN  groot-observer container is not running'

echo "Speech:"
if command -v curl >/dev/null 2>&1; then
  curl -fsS "http://127.0.0.1:${GROOT_PORT:-8787}/api/v1/speech/status" 2>/dev/null || echo "  API speech status unavailable"
  echo
fi
