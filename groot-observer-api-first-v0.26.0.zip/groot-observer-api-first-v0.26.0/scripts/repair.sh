#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '[groot-compose] Rebuilding application image without cache. Runtime/config/codex are preserved.'
docker compose down --remove-orphans
docker compose build --no-cache groot-observer
docker compose up -d groot-observer
