#!/usr/bin/env bash
set -Eeuo pipefail

log(){ printf '[docker-bootstrap] %s\n' "$*"; }
die(){ printf '[docker-bootstrap] ERROR: %s\n' "$*" >&2; exit 1; }

if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  log "Docker and Compose v2 are already installed."
  docker --version
  docker compose version
  exit 0
fi

[ -r /etc/os-release ] || die "This bootstrap currently supports Debian/Ubuntu hosts."
. /etc/os-release
case " ${ID:-} ${ID_LIKE:-} " in
  *debian*|*ubuntu*) ;;
  *) die "Unsupported distribution: ${PRETTY_NAME:-unknown}. Install Docker Engine + Compose v2 with your distribution's package manager." ;;
esac

SUDO=""
if [ "$(id -u)" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || die "sudo is required for host package installation."
  SUDO=sudo
fi

log "Installing distribution Docker Engine and Compose v2 packages."
$SUDO apt-get update
packages=(docker.io)
if apt-cache show docker-compose-v2 >/dev/null 2>&1; then
  packages+=(docker-compose-v2)
elif apt-cache show docker-compose-plugin >/dev/null 2>&1; then
  packages+=(docker-compose-plugin)
else
  die "No Compose v2 package found in configured apt repositories."
fi
$SUDO apt-get install -y "${packages[@]}"

if command -v systemctl >/dev/null 2>&1; then
  $SUDO systemctl enable --now docker
fi

if [ "$(id -u)" -ne 0 ]; then
  if getent group docker >/dev/null 2>&1; then
    $SUDO usermod -aG docker "$USER"
    log "Added $USER to docker group. Log out/in (or run 'newgrp docker') before using Docker without sudo."
  fi
fi

log "Installed versions:"
docker --version || true
docker compose version || true
