# v0.25.0 - Welcome Grid + Warm Family Defaults

- Replaced the dense numbered Bash menu with a dependency-free emoji tile grid.
- Added live service badges for Core, Ollama and Speech plus a family strip.
- Made `llama3.2:3b` the default local model and added a one-shot `ollama-init` seeder.
- Added conservative Ollama defaults for an 8 GB class host: one loaded model and one parallel request.
- Added warmer, relationship-aware family prompting while preserving evidence grounding and non-fabrication rules.
- Added welcome-gather metadata and browser behavior so the family initially gathers near the player on entry.
