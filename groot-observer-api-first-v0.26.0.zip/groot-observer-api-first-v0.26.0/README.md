# GROOT Observer v0.26.0 - Aurora Glass / Voice Repair / AR Lens

GROOT Observer is an API-first local signal observatory. Plug a new signal into the laptop, normalize it into evidence, identify the device/control plane, and then explicitly promote that observation into a short-lived management session.

The retained continuity inputs are:

1. the operator-supplied Codex corpus, stored at `data/codex.json`;
2. the family observer registry in `config/family.json`.

The governing rule remains: **evidence first, control second**.

## Welcome TUI

Run `./groot` with no arguments for the calm server-management TUI. It manages Compose, profiles, logs, rebuilds, web port/bind settings, and Ollama settings. The browser UI is intentionally separate: it is the 3D Signal Commons, not a server dashboard.

Speech is modular in the browser: click an avatar to set the talk target, press the floating microphone for STT, click any reply to read it, or select text anywhere and use the floating READ control. There is no dedicated speech textarea/deck.


## Compose is now the runtime

The host no longer needs a Python virtual environment. Python, FastAPI/Uvicorn, pyserial, networking utilities, BlueZ tools, NetworkManager CLI, V4L2 tooling, ffmpeg, ALSA capture tools, server TTS, USB tools, and SSH live inside the image.

The host needs only Docker and Docker Compose v2. If they are missing on Debian/Ubuntu, `./scripts/bootstrap-docker.sh` can install the distro packages.

```bash
cp .env.example .env
./scripts/install.sh
./scripts/start.sh
./scripts/status.sh
```

Open:

- UI: `http://127.0.0.1:8787`
- OpenAPI: `http://127.0.0.1:8787/docs`

If you change `GROOT_PORT` in `.env`, use that port instead.

## Why it uses host networking

The point is to observe the laptop's actual Ethernet/Wi-Fi/control-plane surfaces. A normal Docker bridge would put GROOT inside a synthetic network namespace. The default therefore uses `network_mode: host`, while the API itself remains bound to `127.0.0.1` unless you deliberately change `GROOT_HOST`.

## Physical signal access

For the dedicated lab observer, `GROOT_PRIVILEGED=true` is the default and Compose exposes host `/dev`, `/sys`, udev and system D-Bus to the container. This lets hot-plugged USB serial, USB Ethernet, Bluetooth, Wi-Fi and V4L2/HDMI capture endpoints appear without rebuilding the image.

Privileged mode is broad host access. Set `GROOT_PRIVILEGED=false` for API-only/sandbox use, with the expectation that some physical adapters will no longer work.

## Change Docker/runtime parameters

Edit `.env` for the everyday knobs:

```dotenv
GROOT_PORT=8787
GROOT_SCAN_INTERVAL_SECONDS=4
GROOT_ALLOW_ACTIVE_PROBE=true
GROOT_ALLOW_WRITE_CONTROL=false
GROOT_PRIVILEGED=true
GROOT_RESTART=unless-stopped
GROOT_OLLAMA_URL=http://127.0.0.1:11434
```

Or edit `docker-compose.yml` directly for mounts, capabilities, networking, restart policy, image tags, etc. Inspect the fully resolved configuration with:

```bash
./scripts/compose-config.sh
```

## Signal/control examples

```bash
./grootctl scan
./grootctl signals
./grootctl neighbors
./grootctl wifi-scan
./grootctl bt-scan
./grootctl discover 192.168.88.1
./grootctl serial-sample /dev/ttyUSB0 9600
```

Target discovery is bounded to an explicit host. It never silently expands into a subnet scan.

Write control remains off by default. Read-only discovery/control can be approved for a short-lived session; configuration commands additionally require `GROOT_ALLOW_WRITE_CONTROL=true` and explicit write scope.

## HDMI reality check

A typical laptop HDMI connector is output-only. To observe an Alexa/Fire TV/console HDMI source, attach an HDMI capture device that Linux exposes as `/dev/videoN`. GROOT can then enumerate that capture endpoint and capture a frame through V4L2/ffmpeg.

## Optional Ollama

```bash
docker compose --profile ollama up -d
```

The optional Ollama service uses host networking too, so GROOT's default `GROOT_OLLAMA_URL=http://127.0.0.1:11434` still works.

See `docs/DOCKER.md`, `docs/API.md`, `docs/SIGNAL-ADAPTERS.md`, and `docs/DESIGN.md`.

## v0.25.0: Inside the Machine

The world now has a visible sky and an internal-computer layer. Walk to **Motherboard Core** to see discovered USB, serial, Ethernet, Wi-Fi, Bluetooth, video and audio streams wired back as luminous transport buses. Walk to **Evidence Vault** for a read-only explorer of `runtime/groot.db`. Walk to **Packet Station** to craft a bounded HTTP/HTTPS journey, board the packet train and arrive at a generated website portal.

Movement is now hard-gated by pointer lock. The moment a UI input receives focus, held movement is cleared and the world stops consuming WASD, so typing names such as `ava` cannot walk the character sideways.

Ollama is enabled in `COMPOSE_PROFILES` for new installs. Use `./groot ollama` for the Ollama TUI, `./groot doctor` for a direct API probe, or the in-world Ollama panel to detect, explicitly pull and select models. No model download happens without an explicit pull action.

The packet train is an observability metaphor tied to real bounded evidence. GROOT resolves DNS and, when active probing is enabled, performs a single HTTP HEAD request. It does not claim unobserved Internet hops or provide arbitrary raw-packet injection.

## v0.23.0: enter the world

The browser now opens on a title screen instead of dropping directly into the dashboard. Choose a character and an installed Ollama model, then enter the Signal Commons as a first-person character.

Controls: `WASD` walk, `Shift` sprint, mouse look, `E` interact, `Tab` or `Esc` release the mouse, and click the world or press `R` to resume walking. Opening conversations, signal controls, speech/model controls, or the discovery rail releases pointer lock automatically.

Discoveries are spatial. Signals materialize as beacons in deterministic transport sectors and the world boundary grows as the discovered frontier grows. `CALM` shows the highest-attention discoveries; `ALL` exposes the wider field. Family NPCs wander independently and gather around a selected signal.

Ollama is now observable rather than assumed. The title screen and in-world model chooser detect `/api/tags`, list installed models, and persist the selected model in `runtime/ollama.json`. No model is silently downloaded.

The v19 browser-overlay lineage is back. Open `/overlay` to generate a one-line loader for the current server. The v0.23-compatible script lives at `/ar-overlay.js`; the untouched v19 source is archived at `/legacy/v19/ar-overlay.js`.

## v0.23.0 Signal Commons

The UI now ranks nearby streams and exposes capability-specific interaction buttons. A stream can be inspected, focused by the family circle, discussed with an individual persona, or interacted with using bounded read actions such as serial sampling, LLDP/IP neighbors, radio scanning and V4L2 snapshots.

The default family circle is Ava, Ayoh, Truce, Klus, Ether, Frankie and Samuel. Conversation is grounded in selected signal evidence and explicit daily check-ins. Ollama is optional; when it is unavailable, the API does not invent observations.

Speech is built in. Browser voices provide instant selectable TTS, server-side `espeak-ng` provides a Compose-local TTS path, and supported browsers provide push-to-talk STT. Browser STT transcripts are ingested into the API evidence/event stream.

See `docs/SIGNAL-COMMONS.md`.


### Local Whisper STT

The floating microphone now prefers local browser audio capture sent to the Compose Whisper sidecar. Browser Web Speech is only a fallback. New installs enable both `speech` and `ollama` profiles in `.env`, so a normal `docker compose up` brings up the full local conversation stack. To start speech explicitly:

```bash
docker compose --profile speech up -d --build
```

The default Whisper model is `tiny` with CPU `int8`, appropriate for modest RAM systems. `GROOT_WHISPER_PRELOAD=true` begins loading it at startup and the model cache is persistent. Use `./groot voice` for speech health, warmup and logs.

ALSA capture endpoints discovered by `arecord -l` appear as audio streams. Their `RECORD + STT` action records a short clip only after an explicit click, then transcribes it through the local speech service.


## v0.25.0: Welcome Grid

Run `./groot` for the emoji tile TUI. The default Ollama seed is `llama3.2:3b`; the `ollama-init` Compose service installs it on first startup when the Ollama profile is enabled. The family circle also carries warmer relationship-aware conversation metadata while preserving evidence grounding.


## v0.26.0: Aurora Glass + working local voice

The main UI and overlay now share an Aurora Glass theme with persisted light/dark mode. The font stack favors modern local system display and coding fonts without bundling font files.

The microphone path is now local-first: MediaRecorder captures only after the mic button is pressed, sends the clip to `/api/v1/speech/stt`, and the Whisper sidecar transcribes it. Browser SpeechRecognition remains a fallback. Server TTS continues through `espeak-ng`, while browser-installed voices remain selectable.

Open `/overlay` for the AR Lens launcher. The page no longer prints the bookmarklet source; it exposes a single **COPY OVERLAY LOADER** action. The injected lens is a compact liquid-glass observability panel with family chat, installed Ollama model selection, GROOT signal discovery, and non-invasive page observable-surface discovery. Browser APIs do not expose a reliable list of pre-existing observers or human viewers, so the overlay labels observer APIs and reactive DOM surfaces as evidence rather than claiming unseen watchers.
