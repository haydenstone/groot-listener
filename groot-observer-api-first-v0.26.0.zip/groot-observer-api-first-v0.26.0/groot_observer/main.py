from __future__ import annotations
import uvicorn
from .config import Settings

def run():
    s=Settings.load()
    uvicorn.run('groot_observer.api:app',host=s.api_host,port=s.api_port,reload=False)

if __name__=='__main__': run()
