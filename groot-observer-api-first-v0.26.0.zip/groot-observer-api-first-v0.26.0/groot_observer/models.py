from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Literal
from pydantic import BaseModel, Field

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

class Evidence(BaseModel):
    kind: str
    source: str
    summary: str
    data: dict[str, Any] = Field(default_factory=dict)
    observed_at: str = Field(default_factory=now_iso)

class Signal(BaseModel):
    id: str
    transport: Literal["usb","serial","ethernet","wifi","bluetooth","video","audio","unknown"]
    name: str
    locator: str
    state: Literal["present","up","down","unknown"] = "present"
    confidence: float = 0.5
    capabilities: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    evidence: list[Evidence] = Field(default_factory=list)
    first_seen: str = Field(default_factory=now_iso)
    last_seen: str = Field(default_factory=now_iso)

class Device(BaseModel):
    id: str
    name: str
    vendor: str | None = None
    model: str | None = None
    management_addresses: list[str] = Field(default_factory=list)
    transports: list[str] = Field(default_factory=list)
    profile_id: str | None = None
    signal_ids: list[str] = Field(default_factory=list)
    evidence: list[Evidence] = Field(default_factory=list)

class ProbeRequest(BaseModel):
    signal_id: str | None = None
    target: str | None = None
    transport: str | None = None
    active: bool = False

class ControlDiscoverRequest(BaseModel):
    target: str
    ports: list[int] | None = None

class SerialProbeRequest(BaseModel):
    port: str
    baud: int = 9600
    timeout_seconds: float = 1.5

class ApprovalRequest(BaseModel):
    target: str
    transport: Literal["ssh","serial"]
    scopes: list[Literal["read","write"]] = Field(default_factory=lambda:["read"])
    ttl_seconds: int = 900

class ControlCommandRequest(BaseModel):
    session_id: str
    command: str
    username: str | None = None
    port: int = 22
    serial_baud: int = 9600

class FamilyFocusRequest(BaseModel):
    signal_id: str
    persona_ids: list[str] | None = None



class OllamaModelSelectRequest(BaseModel):
    model: str = "auto"



class OllamaModelPullRequest(BaseModel):
    model: str

class PacketJourneyRequest(BaseModel):
    url: str
    label: str | None = None
    ttl: int = Field(default=64, ge=1, le=255)

class TalkRequest(BaseModel):
    message: str
    signal_id: str | None = None

class CircleTalkRequest(BaseModel):
    message: str
    signal_id: str | None = None
    persona_ids: list[str] | None = None

class CheckInRequest(BaseModel):
    persona_id: str
    text: str
    mood: str | None = None

class SpeechSynthesisRequest(BaseModel):
    text: str
    voice: str | None = None
    persona_id: str | None = None
    rate: float = 1.0
    pitch: float = 1.0

class STTIngestRequest(BaseModel):
    text: str
    confidence: float | None = None
    language: str | None = None
    source: str = "browser-web-speech"

class StreamInteractRequest(BaseModel):
    action: str
    baud: int = 9600
    timeout_seconds: float = 1.5
