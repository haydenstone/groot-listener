from __future__ import annotations
import json, re, shutil, subprocess
from pathlib import Path

class SpeechEngine:
    def __init__(self, voices_path: Path):
        self.voices_path = voices_path
        self.config = json.loads(voices_path.read_text()) if voices_path.exists() else {}

    def server_voices(self) -> list[dict]:
        if not shutil.which("espeak-ng"):
            return []
        try:
            out = subprocess.check_output(["espeak-ng", "--voices"], text=True, stderr=subprocess.DEVNULL, timeout=4)
        except Exception:
            return []
        rows=[]
        for line in out.splitlines()[1:]:
            parts=line.split()
            if len(parts) < 4: continue
            rows.append({"language":parts[1], "gender":parts[2], "name":parts[3], "provider":"espeak-ng"})
        return rows

    def preferred_voice(self, persona_id: str | None) -> str:
        if persona_id:
            x=self.config.get("personas",{}).get(persona_id,{})
            if x.get("server_voice"): return x["server_voice"]
        return self.config.get("server_default","en-us")

    def synthesize(self, text: str, voice: str | None=None, rate: float=1.0, pitch: float=1.0, persona_id: str | None=None) -> bytes:
        text=(text or "").strip()
        if not text: raise ValueError("text is required")
        if len(text) > 12000: raise ValueError("text is limited to 12000 characters per request")
        if not shutil.which("espeak-ng"): raise RuntimeError("server TTS unavailable: espeak-ng is not installed")
        voice=voice or self.preferred_voice(persona_id)
        # eSpeak uses words/minute and pitch 0-99. Keep browser-like multipliers at the API.
        speed=max(80,min(450,int(175*max(.45,min(2.5,rate)))))
        epitch=max(0,min(99,int(50*max(.2,min(1.8,pitch)))))
        cmd=["espeak-ng","--stdout","-v",voice,"-s",str(speed),"-p",str(epitch),text]
        try:
            return subprocess.check_output(cmd, stderr=subprocess.PIPE, timeout=45)
        except subprocess.CalledProcessError as e:
            raise RuntimeError((e.stderr or b"TTS failed").decode(errors="replace")[:1000])

    def status(self) -> dict:
        return {
            "tts": {
                "browser": True,
                "server": bool(shutil.which("espeak-ng")),
                "server_provider": "espeak-ng" if shutil.which("espeak-ng") else None,
            },
            "stt": {
                "browser_web_speech": True,
                "browser_media_recorder": True,
                "local_whisper": False,
                "note": "The UI prefers local MediaRecorder → Whisper STT when the speech sidecar is healthy, with browser SpeechRecognition as a fallback."
            }
        }
