from __future__ import annotations
from datetime import datetime, timezone
from .models import Signal

TRANSPORT_GROUP = {
    "serial": "console",
    "ethernet": "network",
    "wifi": "network",
    "bluetooth": "radio",
    "video": "media",
    "audio": "media",
    "usb": "hardware",
    "unknown": "other",
}

TRANSPORT_WEIGHT = {
    "serial": 18,
    "video": 16,
    "audio": 17,
    "ethernet": 14,
    "wifi": 13,
    "bluetooth": 11,
    "usb": 9,
    "unknown": 0,
}

def _age_seconds(iso: str) -> float:
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds())
    except Exception:
        return 999999.0

def action_catalog(s: Signal) -> list[dict]:
    actions = [
        {"id": "inspect", "label": "INSPECT", "mode": "observe"},
        {"id": "focus", "label": "FAMILY FOCUS", "mode": "observe"},
        {"id": "ask", "label": "ASK ABOUT IT", "mode": "observe"},
    ]
    if s.transport == "serial":
        actions.append({"id": "serial-sample", "label": "SAMPLE CONSOLE", "mode": "active-read"})
    elif s.transport == "video":
        actions.append({"id": "snapshot", "label": "SNAPSHOT", "mode": "active-read"})
    elif s.transport == "audio":
        actions.append({"id": "audio-transcribe", "label": "RECORD + STT", "mode": "active-read"})
    elif s.transport == "wifi":
        actions.append({"id": "wifi-scan", "label": "SCAN WI-FI", "mode": "active-read"})
    elif s.transport == "bluetooth":
        actions.append({"id": "bluetooth-scan", "label": "SCAN BLUETOOTH", "mode": "active-read"})
    elif s.transport == "ethernet":
        actions.append({"id": "neighbors", "label": "NEIGHBORS", "mode": "active-read"})
    return actions

def stream_view(s: Signal) -> dict:
    age = _age_seconds(s.last_seen)
    freshness = 20 if age < 10 else 12 if age < 60 else 5 if age < 300 else 0
    state = 18 if s.state in {"up", "present"} else 0
    score = round(TRANSPORT_WEIGHT.get(s.transport, 0) + state + (s.confidence * 40) + freshness + min(10, len(s.capabilities) * 2), 2)
    return {
        "signal": s.model_dump(),
        "group": TRANSPORT_GROUP.get(s.transport, "other"),
        "attention_score": score,
        "reason": f"{s.transport} · {s.state} · confidence {s.confidence:.2f} · {len(s.capabilities)} capabilities",
        "actions": action_catalog(s),
    }

def sort_streams(signals: list[Signal]) -> list[dict]:
    return sorted((stream_view(s) for s in signals), key=lambda x: (-x["attention_score"], x["signal"]["name"].lower()))
