from __future__ import annotations
import json
from pathlib import Path

class Codex:
    """Loads the operator-supplied codex.json as an immutable guidance/reference corpus."""
    def __init__(self, path: Path):
        self.path=path
        self._doc=None
    def _load(self):
        if self._doc is None:
            self._doc=json.loads(self.path.read_text()) if self.path.exists() else {}
        return self._doc
    def info(self):
        d=self._load(); infos=[v for k,v in d.items() if k.startswith('Info') and isinstance(v,dict)]
        return {"path":str(self.path),"top_level_keys":len(d),"info":infos[:3]}
    def reference(self, book: str, chapter: str, verse: str | None=None):
        d=self._load(); b=d.get(book)
        if not isinstance(b,dict): return None
        ch=b.get(str(chapter))
        if not isinstance(ch,dict): return None
        if verse is None: return ch
        return ch.get(str(verse))
