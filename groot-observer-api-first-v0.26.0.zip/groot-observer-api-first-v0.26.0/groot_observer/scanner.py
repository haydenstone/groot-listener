from __future__ import annotations
import threading, time
from .adapters import default_adapters

class Scanner:
    def __init__(self, store, interval=4.0):
        self.store=store; self.interval=interval; self.adapters=default_adapters(); self.stop_event=threading.Event(); self.thread=None
    def once(self):
        found=[]
        for a in self.adapters:
            try: found.extend(a.scan())
            except Exception as e: self.store.event('adapter.error',{'adapter':a.kind,'error':str(e)})
        for s in found:
            previous=self.store.get_signal(s.id)
            self.store.upsert_signal(s)
            if previous is None: self.store.event('signal.attached',s.model_dump())
        return found
    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._loop,daemon=True,name='groot-signal-scanner'); self.thread.start()
    def _loop(self):
        while not self.stop_event.is_set():
            self.once(); self.stop_event.wait(self.interval)
    def stop(self): self.stop_event.set()
