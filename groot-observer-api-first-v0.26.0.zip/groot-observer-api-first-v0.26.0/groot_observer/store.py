from __future__ import annotations
import json, sqlite3, threading, time, uuid
from pathlib import Path
from .models import Signal, Device

class Store:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("create table if not exists signals (id text primary key, body text not null, updated real not null)")
        self.db.execute("create table if not exists devices (id text primary key, body text not null, updated real not null)")
        self.db.execute("create table if not exists events (seq integer primary key autoincrement, kind text, body text, ts real)")
        self.db.execute("create table if not exists sessions (id text primary key, target text, transport text, scopes text, expires real)")
        self.db.execute("create table if not exists checkins (id text primary key, persona_id text, text text, mood text, ts real)")
        self.db.commit()

    def upsert_signal(self, s: Signal):
        with self.lock:
            old = self.get_signal(s.id)
            if old: s.first_seen = old.first_seen
            self.db.execute("insert or replace into signals values (?,?,?)", (s.id, s.model_dump_json(), time.time()))
            self.db.commit()

    def list_signals(self) -> list[Signal]:
        with self.lock:
            rows = self.db.execute("select body from signals order by updated desc").fetchall()
        return [Signal.model_validate_json(r[0]) for r in rows]

    def get_signal(self, sid: str) -> Signal | None:
        with self.lock:
            row = self.db.execute("select body from signals where id=?", (sid,)).fetchone()
        return Signal.model_validate_json(row[0]) if row else None

    def upsert_device(self, d: Device):
        with self.lock:
            self.db.execute("insert or replace into devices values (?,?,?)", (d.id, d.model_dump_json(), time.time()))
            self.db.commit()

    def list_devices(self) -> list[Device]:
        with self.lock:
            rows = self.db.execute("select body from devices order by updated desc").fetchall()
        return [Device.model_validate_json(r[0]) for r in rows]

    def event(self, kind: str, body: dict):
        with self.lock:
            self.db.execute("insert into events(kind,body,ts) values(?,?,?)", (kind, json.dumps(body), time.time()))
            self.db.execute("delete from events where seq not in (select seq from events order by seq desc limit 1000)")
            self.db.commit()

    def recent_events(self, after: int = 0, limit: int = 200):
        with self.lock:
            rows = self.db.execute("select seq,kind,body,ts from events where seq>? order by seq limit ?", (after,limit)).fetchall()
        return [{"seq":r[0],"kind":r[1],"body":json.loads(r[2]),"ts":r[3]} for r in rows]

    def add_checkin(self, persona_id: str, text: str, mood: str | None = None):
        cid = uuid.uuid4().hex
        now = time.time()
        with self.lock:
            self.db.execute("insert into checkins values (?,?,?,?,?)", (cid, persona_id, text, mood, now))
            self.db.commit()
        return {"id":cid,"persona_id":persona_id,"text":text,"mood":mood,"ts":now}

    def today_checkins(self, persona_id: str | None = None):
        start = time.time() - (time.localtime().tm_hour*3600 + time.localtime().tm_min*60 + time.localtime().tm_sec)
        with self.lock:
            if persona_id:
                rows=self.db.execute("select id,persona_id,text,mood,ts from checkins where ts>=? and persona_id=? order by ts",(start,persona_id)).fetchall()
            else:
                rows=self.db.execute("select id,persona_id,text,mood,ts from checkins where ts>=? order by ts",(start,)).fetchall()
        return [{"id":r[0],"persona_id":r[1],"text":r[2],"mood":r[3],"ts":r[4]} for r in rows]


    def db_summary(self):
        """Return a read-only inventory of the local SQLite evidence store."""
        with self.lock:
            tables = [r[0] for r in self.db.execute(
                "select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name"
            ).fetchall()]
            out=[]
            for name in tables:
                safe='"'+name.replace('"','""')+'"'
                count=self.db.execute(f"select count(*) from {safe}").fetchone()[0]
                cols=[{"name":r[1],"type":r[2],"pk":bool(r[5])} for r in self.db.execute(f"pragma table_info({safe})").fetchall()]
                out.append({"name":name,"rows":count,"columns":cols})
        try:
            size=self.path.stat().st_size
        except Exception:
            size=0
        return {"database":self.path.name,"bytes":size,"tables":out}

    def db_table(self, table: str, limit: int = 100, offset: int = 0):
        """Read one whitelisted SQLite table without accepting arbitrary SQL."""
        limit=max(1,min(int(limit),500)); offset=max(0,int(offset))
        with self.lock:
            allowed={r[0] for r in self.db.execute(
                "select name from sqlite_master where type='table' and name not like 'sqlite_%'"
            ).fetchall()}
            if table not in allowed:
                raise KeyError(table)
            safe='"'+table.replace('"','""')+'"'
            cur=self.db.execute(f"select * from {safe} limit ? offset ?",(limit,offset))
            names=[x[0] for x in cur.description]
            raw=cur.fetchall()
            total=self.db.execute(f"select count(*) from {safe}").fetchone()[0]
        rows=[]
        for r in raw:
            row={}
            for k,v in zip(names,r):
                if isinstance(v,str) and v[:1] in ('{','['):
                    try:
                        row[k]=json.loads(v)
                        continue
                    except Exception:
                        pass
                row[k]=v
            rows.append(row)
        return {"table":table,"total":total,"limit":limit,"offset":offset,"columns":names,"rows":rows}

    def approve(self, target: str, transport: str, scopes: list[str], ttl: int) -> str:
        sid = uuid.uuid4().hex
        with self.lock:
            self.db.execute("insert into sessions values (?,?,?,?,?)", (sid,target,transport,json.dumps(scopes),time.time()+ttl))
            self.db.commit()
        return sid

    def session(self, sid: str):
        with self.lock:
            row = self.db.execute("select target,transport,scopes,expires from sessions where id=?", (sid,)).fetchone()
        if not row or row[3] < time.time(): return None
        return {"id":sid,"target":row[0],"transport":row[1],"scopes":json.loads(row[2]),"expires":row[3]}
