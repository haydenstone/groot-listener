from __future__ import annotations
import asyncio, shutil, json, secrets, urllib.parse, socket, time
import httpx
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, UploadFile, File, Form, Request
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from . import __version__
from .config import ROOT, Settings
from .models import (
    ControlDiscoverRequest, SerialProbeRequest, ApprovalRequest, ControlCommandRequest,
    FamilyFocusRequest, TalkRequest, CircleTalkRequest, CheckInRequest, SpeechSynthesisRequest, STTIngestRequest,
    StreamInteractRequest, OllamaModelSelectRequest, OllamaModelPullRequest, PacketJourneyRequest,
)
from .store import Store
from .scanner import Scanner
from .discovery import ControlPlaneDiscovery
from .control import ControlRunner
from .codex import Codex
from .family import FamilyCouncil
from .radio import wifi_scan, bluetooth_scan
from .capture import snapshot, record_audio
from .streams import sort_streams, stream_view
from .speech import SpeechEngine
from .conversation import ConversationEngine

settings=Settings.load()
store=Store(ROOT/'runtime/groot.db')
scanner=Scanner(store,settings.scan_interval_seconds)
discovery=ControlPlaneDiscovery(ROOT/'config/device_profiles.json')
control=ControlRunner(store,settings.allow_write_control)
codex=Codex(ROOT/settings.codex_path)
family=FamilyCouncil(ROOT/'config/family.json', ROOT/settings.family_circle_path)
speech=SpeechEngine(ROOT/settings.voices_path)
conversation=ConversationEngine(family,store,settings)

OVERLAY_TOKEN_PATH = ROOT/'runtime/overlay-token.txt'
def _overlay_token() -> str:
    value = None
    try:
        value = __import__('os').getenv('GROOT_OVERLAY_TOKEN')
    except Exception:
        value = None
    if value:
        return value.strip()
    try:
        if OVERLAY_TOKEN_PATH.exists():
            value = OVERLAY_TOKEN_PATH.read_text().strip()
            if value:
                return value
        OVERLAY_TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
        value = secrets.token_urlsafe(24)
        OVERLAY_TOKEN_PATH.write_text(value+'\n')
        return value
    except Exception:
        return ''

def _overlay_auth(token: str | None):
    expected = _overlay_token()
    if not expected or not token or not secrets.compare_digest(expected, token):
        raise HTTPException(401, 'invalid overlay token')

def _overlay_json(payload, status_code: int=200):
    return JSONResponse(payload, status_code=status_code, headers={
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-store',
        'Vary': 'Origin',
    })

@asynccontextmanager
async def lifespan(_app: FastAPI):
    scanner.once(); scanner.start()
    try:
        yield
    finally:
        scanner.stop()

app=FastAPI(
    title='GROOT Observer API',
    version=__version__,
    description='Local Signal Commons. Observation is default; control requires explicit, expiring approval.',
    lifespan=lifespan,
)
app.mount('/static',StaticFiles(directory=ROOT/'groot_observer/static'),name='static')

@app.get('/')
def root(): return FileResponse(ROOT/'groot_observer/static/index.html')

@app.get('/api/v1/health')
def health():
    return {
        'ok':True,'version':__version__,'write_control':settings.allow_write_control,
        'local_only':settings.local_only,'speech_enabled':settings.speech_enabled,
        'ollama_model':conversation.status().get('configured'),'ollama_url':settings.ollama_url,
        'ollama_runtime':conversation.status(),
    }

@app.get('/api/v1/ollama/status')
def ollama_status():
    return conversation.models()

@app.get('/api/v1/ollama/models')
def ollama_models():
    return conversation.models()

@app.post('/api/v1/ollama/model')
def ollama_model(req: OllamaModelSelectRequest):
    try:
        return conversation.select_model(req.model)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(503, f'Ollama model selection failed: {e}')

@app.post('/api/v1/ollama/pull')
def ollama_pull(req: OllamaModelPullRequest):
    try:
        return conversation.pull_model(req.model)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(503, f'Ollama model pull failed: {e}')

@app.get('/overlay')
def overlay_page():
    return FileResponse(ROOT/'groot_observer/static/overlay.html')

@app.get('/ar-overlay.js')
def overlay_script():
    return FileResponse(ROOT/'groot_observer/static/ar-overlay.js', media_type='application/javascript')

@app.get('/legacy/v19/ar-overlay.js')
def legacy_overlay_script():
    return FileResponse(ROOT/'groot_observer/static/ar-overlay-v19.js', media_type='application/javascript')

@app.get('/api/v1/overlay/config')
def overlay_config():
    return {
        'relay': f'http://127.0.0.1:{settings.api_port}',
        'token': _overlay_token(),
        'familySeed': family.circle() or family.personas(),
        'scope': 'all',
        'version': __version__,
    }

@app.get('/api/v1/overlay/family')
def overlay_family(token: str):
    _overlay_auth(token)
    return _overlay_json({'family': family.circle() or family.personas()})

@app.get('/api/v1/overlay/streams')
def overlay_streams(token: str):
    _overlay_auth(token)
    return _overlay_json({'streams': sort_streams(store.list_signals())})

@app.get('/api/v1/overlay/models')
def overlay_models(token: str):
    _overlay_auth(token)
    return _overlay_json(conversation.models())

@app.post('/api/v1/overlay/model')
async def overlay_model(request: Request, token: str):
    _overlay_auth(token)
    body=(await request.body()).decode('utf-8','replace')
    fields=urllib.parse.parse_qs(body)
    model=(fields.get('model') or ['auto'])[0]
    try:
        return _overlay_json(conversation.select_model(model))
    except ValueError as e:
        return _overlay_json({'detail':str(e)},400)
    except Exception as e:
        return _overlay_json({'detail':f'Ollama model selection failed: {e}'},503)

@app.post('/api/v1/overlay/talk')
async def overlay_talk(request: Request, token: str):
    _overlay_auth(token)
    body=(await request.body()).decode('utf-8','replace')
    fields=urllib.parse.parse_qs(body)
    persona_id=(fields.get('persona_id') or ['ava-stone'])[0]
    message=(fields.get('message') or [''])[0].strip()
    signal_id=(fields.get('signal_id') or [''])[0] or None
    if not message:
        return _overlay_json({'detail':'message is required'},400)
    sig=store.get_signal(signal_id) if signal_id else None
    try:
        return _overlay_json(conversation.talk(persona_id,message,sig))
    except KeyError:
        return _overlay_json({'detail':'persona not found'},404)

@app.get('/api/v1/capabilities')
def capabilities():
    return {
      'adapters':['usb','serial','ethernet','wifi','bluetooth','video','audio'],
      'signal_commons':['intelligent-stream-sorting','family-focus','persona-talk','daily-checkins','tts','browser-stt','db-explorer','packet-transit'],
      'control':['targeted-management-port-discovery','serial-read-sample','ssh-explicit-session','serial-explicit-session'],
      'tools':{x:bool(shutil.which(x)) for x in ['ip','nmcli','bluetoothctl','v4l2-ctl','ffmpeg','arecord','ssh','lldpctl','espeak-ng']},
      'speech':speech.status(),
      'notes':{
          'hdmi':'Laptop HDMI ports are usually outputs. HDMI sources require an HDMI capture/input device exposed by the OS.',
          'nearby':'Nearby means observed by this laptop. Control or connection actions remain explicit and permission-gated.'
      }
    }

@app.get('/api/v1/environment')
def environment():
    path=ROOT/'config/environment.json'
    if not path.exists():
        return {'name':'GROOT Signal Commons','districts':[],'scene':{'family_center':{'x':50,'z':50},'max_visible_streams':10}}
    return json.loads(path.read_text())

@app.get('/api/v1/db/summary')
def db_summary():
    return store.db_summary()

@app.get('/api/v1/db/table/{table}')
def db_table(table: str, limit: int = 100, offset: int = 0):
    try:
        return store.db_table(table, limit, offset)
    except KeyError:
        raise HTTPException(404, 'database table not found')

@app.post('/api/v1/transit/journey')
def transit_journey(req: PacketJourneyRequest):
    raw=req.url.strip()
    if not raw:
        raise HTTPException(400, 'destination URL is required')
    if '://' not in raw:
        raw='https://'+raw
    parsed=urllib.parse.urlparse(raw)
    if parsed.scheme not in {'http','https'} or not parsed.hostname:
        raise HTTPException(400, 'destination must be an http or https URL')
    if parsed.username or parsed.password:
        raise HTTPException(400, 'credentials are not accepted in packet destinations')
    host=parsed.hostname
    port=parsed.port or (443 if parsed.scheme=='https' else 80)
    started=time.time()
    addresses=[]
    dns_error=None
    try:
        infos=socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        for info in infos:
            ip=info[4][0]
            if ip not in addresses:
                addresses.append(ip)
    except Exception as e:
        dns_error=str(e)
    phases=[
        {'id':'craft','label':'Packet crafted','ok':True,'detail':f'{parsed.scheme.upper()} HEAD · TTL {req.ttl}'},
        {'id':'dns','label':'DNS resolution','ok':bool(addresses),'detail':', '.join(addresses[:4]) if addresses else (dns_error or 'unresolved')},
        {'id':'bus','label':'Host network bus','ok':True,'detail':'GROOT transit station → network control plane'},
    ]
    status_code=None; final_url=raw; remote_headers={}; request_error=None
    if settings.allow_active_probe and addresses:
        try:
            with httpx.Client(timeout=10.0, follow_redirects=True, headers={'User-Agent':f'GROOT-Transit/{__version__}'}) as client:
                r=client.head(raw)
            status_code=r.status_code; final_url=str(r.url)
            for k in ('server','content-type','content-length','location','via'):
                if k in r.headers:
                    remote_headers[k]=r.headers[k][:500]
            phases.extend([
                {'id':'tcp','label':'TCP route','ok':True,'detail':f'{addresses[0]}:{port}'},
                {'id':'app','label':'Website response','ok':True,'detail':f'HTTP {status_code} · {final_url}'},
            ])
        except Exception as e:
            request_error=str(e)
            phases.extend([
                {'id':'tcp','label':'TCP route','ok':False,'detail':request_error},
                {'id':'app','label':'Website response','ok':False,'detail':'No HTTP response captured'},
            ])
    else:
        phases.append({'id':'tcp','label':'TCP route','ok':None,'detail':'planned only; active probe disabled' if not settings.allow_active_probe else 'DNS unresolved'})
    packet={
        'label':req.label or host,'url':raw,'host':host,'scheme':parsed.scheme,'port':port,
        'ttl':req.ttl,'application':'http','transport':'tcp','method':'HEAD','payload_bytes':0,
        'resolved_addresses':addresses[:8],
    }
    result={'packet':packet,'phases':phases,'status_code':status_code,'final_url':final_url,'headers':remote_headers,'error':request_error,'elapsed_ms':round((time.time()-started)*1000,1)}
    store.event('transit.journey', {'packet':packet,'status_code':status_code,'final_url':final_url,'error':request_error})
    return result

@app.get('/api/v1/signals')
def signals(): return [x.model_dump() for x in store.list_signals()]

@app.get('/api/v1/signals/{signal_id}')
def signal(signal_id:str):
    x=store.get_signal(signal_id)
    if not x: raise HTTPException(404,'signal not found')
    return x.model_dump()

@app.post('/api/v1/scan')
def scan(): return {'signals':[x.model_dump() for x in scanner.once()]}

@app.get('/api/v1/streams')
def streams():
    return sort_streams(store.list_signals())

@app.get('/api/v1/streams/{signal_id}')
def stream(signal_id:str):
    s=store.get_signal(signal_id)
    if not s: raise HTTPException(404,'signal not found')
    return stream_view(s)

@app.post('/api/v1/streams/{signal_id}/interact')
def stream_interact(signal_id:str, req: StreamInteractRequest):
    s=store.get_signal(signal_id)
    if not s: raise HTTPException(404,'signal not found')
    action=req.action
    if action=='inspect': return {'signal':s.model_dump(),'view':stream_view(s)}
    if action=='focus': return {'signal':s.model_dump(),'family':family.focus(s)}
    if action=='ask': return {'signal_id':s.id,'hint':'Select a family member and ask about this stream.'}
    if action in {'serial-sample','wifi-scan','bluetooth-scan','neighbors','audio-transcribe'} and not settings.allow_active_probe:
        raise HTTPException(403,'active probe disabled')
    if action=='serial-sample':
        if s.transport!='serial': raise HTTPException(400,'not a serial signal')
        try:
            result=discovery.serial_sample(s.locator,req.baud,req.timeout_seconds)
            store.event('stream.serial.sample',{'signal_id':s.id,'locator':s.locator,'baud':req.baud})
            return result
        except Exception as e: raise HTTPException(400,str(e))
    if action=='audio-transcribe':
        if s.transport!='audio': raise HTTPException(400,'not an audio signal')
        try:
            wav=record_audio(s.locator,4)
            with httpx.Client(timeout=90) as client:
                r=client.post(settings.stt_url.rstrip('/')+'/v1/audio/transcriptions',files={'file':('stream.wav',wav,'audio/wav')},data={'language':''})
            if r.status_code >= 400:
                detail=r.text[:2000]
                try: detail=r.json().get('detail',detail)
                except Exception: pass
                raise HTTPException(502,f'local STT service: {detail}')
            out=r.json(); store.event('stream.audio.transcribed',{'signal_id':s.id,'locator':s.locator,'text':out.get('text','')[:2000]}); return out
        except HTTPException: raise
        except Exception as e: raise HTTPException(503,f'audio/STT failed: {e}')
    if action=='wifi-scan':
        result=wifi_scan(); store.event('radio.wifi.scan',{'signal_id':s.id,'count':len(result.get('networks',[]))}); return result
    if action=='bluetooth-scan':
        result=bluetooth_scan(8); store.event('radio.bluetooth.scan',{'signal_id':s.id,'count':len(result.get('devices',[]))}); return result
    if action=='neighbors': return discovery.neighbors()
    raise HTTPException(400,'unsupported stream action')

@app.get('/api/v1/streams/{signal_id}/snapshot')
def stream_snapshot(signal_id:str):
    s=store.get_signal(signal_id)
    if not s: raise HTTPException(404,'signal not found')
    if s.transport!='video': raise HTTPException(400,'not a video stream')
    try:
        store.event('stream.video.snapshot',{'signal_id':s.id,'locator':s.locator})
        return Response(content=snapshot(s.locator),media_type='image/jpeg')
    except Exception as e: raise HTTPException(400,str(e))

@app.get('/api/v1/neighbors')
def neighbors(): return discovery.neighbors()

@app.post('/api/v1/radio/wifi/scan')
def radio_wifi_scan():
    if not settings.allow_active_probe: raise HTTPException(403,'active probe disabled')
    result=wifi_scan(); store.event('radio.wifi.scan',{'count':len(result.get('networks',[]))}); return result

@app.post('/api/v1/radio/bluetooth/scan')
def radio_bluetooth_scan(timeout_seconds:int=8):
    if not settings.allow_active_probe: raise HTTPException(403,'active probe disabled')
    result=bluetooth_scan(timeout_seconds); store.event('radio.bluetooth.scan',{'count':len(result.get('devices',[]))}); return result

@app.get('/api/v1/video/snapshot')
def video_snapshot(device:str):
    try: return Response(content=snapshot(device),media_type='image/jpeg')
    except Exception as e: raise HTTPException(400,str(e))

@app.get('/api/v1/devices')
def devices(): return [x.model_dump() for x in store.list_devices()]

@app.post('/api/v1/control-plane/discover')
def control_discover(req: ControlDiscoverRequest):
    if not settings.allow_active_probe: raise HTTPException(403,'active probe disabled')
    d=discovery.target(req.target,req.ports); store.upsert_device(d); store.event('device.discovered',d.model_dump()); return d.model_dump()

@app.post('/api/v1/control-plane/serial-sample')
def serial_sample(req: SerialProbeRequest):
    if not settings.allow_active_probe: raise HTTPException(403,'active probe disabled')
    try: return discovery.serial_sample(req.port,req.baud,req.timeout_seconds)
    except Exception as e: raise HTTPException(400,str(e))

@app.post('/api/v1/control/approve')
def approve(req: ApprovalRequest):
    if 'write' in req.scopes and not settings.allow_write_control: raise HTTPException(403,'write control is disabled by configuration')
    sid=store.approve(req.target,req.transport,req.scopes,max(30,min(req.ttl_seconds,3600)))
    return {'session_id':sid,'target':req.target,'transport':req.transport,'scopes':req.scopes,'expires_in_seconds':max(30,min(req.ttl_seconds,3600))}

@app.post('/api/v1/control/execute')
def execute(req: ControlCommandRequest):
    try:
        result=control.execute(req.session_id,req.command,req.username,req.port,req.serial_baud)
        store.event('control.executed',{'session_id':req.session_id,'command':req.command,'returncode':result['returncode']})
        return result
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))

@app.get('/api/v1/family')
def family_list(): return family.circle() or family.personas()

@app.get('/api/v1/family/circle')
def family_circle(): return family.circle()

@app.post('/api/v1/family/focus')
def family_focus(req: FamilyFocusRequest):
    s=store.get_signal(req.signal_id)
    if not s: raise HTTPException(404,'signal not found')
    return {'signal':s.model_dump(),'family':family.focus(s,req.persona_ids)}

@app.post('/api/v1/talk/circle')
def talk_circle(req: CircleTalkRequest):
    s=None
    if req.signal_id:
        s=store.get_signal(req.signal_id)
        if not s: raise HTTPException(404,'signal not found')
    return conversation.talk_circle(req.message,s,req.persona_ids)

@app.post('/api/v1/talk/{persona_id}')
def talk(persona_id:str, req: TalkRequest):
    s=None
    if req.signal_id:
        s=store.get_signal(req.signal_id)
        if not s: raise HTTPException(404,'signal not found')
    try: return conversation.talk(persona_id,req.message,s)
    except KeyError: raise HTTPException(404,'persona not found')

@app.post('/api/v1/checkin')
def checkin(req: CheckInRequest):
    if not family.get_persona(req.persona_id): raise HTTPException(404,'persona not found')
    row=store.add_checkin(req.persona_id,req.text,req.mood)
    store.event('family.checkin',row)
    return row

@app.get('/api/v1/day/summary')
def day_summary():
    rows=store.today_checkins()
    events=store.recent_events(0,1000)
    by_person={}
    for r in rows: by_person.setdefault(r['persona_id'],[]).append(r)
    return {
        'checkins':rows,
        'by_person':by_person,
        'observed_event_count':len(events),
        'signal_count':len(store.list_signals()),
        'note':'This summary reports recorded check-ins and observed events only; it does not infer anyone’s feelings.'
    }

@app.get('/api/v1/speech/status')
def speech_status():
    x=speech.status()
    x['enabled']=settings.speech_enabled
    x['stt']['local_whisper_url']=settings.stt_url
    try:
        r=httpx.get(settings.stt_url.rstrip('/')+'/health',timeout=1.6)
        if r.status_code < 400:
            h=r.json()
            x['stt']['local_whisper']=True
            x['stt']['local_whisper_health']=h
        else:
            x['stt']['local_whisper_error']=f'HTTP {r.status_code}'
    except Exception as e:
        x['stt']['local_whisper_error']=str(e)
    return x

@app.get('/api/v1/speech/voices')
def speech_voices():
    return {'browser':{'provider':'Web Speech API','voices':'enumerated by the browser'},'server':speech.server_voices()}

@app.post('/api/v1/speech/tts')
def speech_tts(req: SpeechSynthesisRequest):
    if not settings.speech_enabled: raise HTTPException(403,'speech disabled')
    try:
        wav=speech.synthesize(req.text,req.voice,req.rate,req.pitch,req.persona_id)
        store.event('speech.tts',{'persona_id':req.persona_id,'voice':req.voice or speech.preferred_voice(req.persona_id),'chars':len(req.text)})
        return Response(content=wav,media_type='audio/wav',headers={'Cache-Control':'no-store'})
    except Exception as e: raise HTTPException(400,str(e))

@app.post('/api/v1/speech/stt')
async def speech_stt(file: UploadFile=File(...), language: str|None=Form(None)):
    if not settings.speech_enabled: raise HTTPException(403,'speech disabled')
    data=await file.read()
    if not data: raise HTTPException(400,'empty audio file')
    if len(data) > 30*1024*1024: raise HTTPException(413,'audio file too large; limit is 30 MB')
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            r=await client.post(settings.stt_url.rstrip('/')+'/v1/audio/transcriptions',files={'file':(file.filename or 'audio.webm',data,file.content_type or 'application/octet-stream')},data={'language':language or ''})
        if r.status_code >= 400:
            detail=r.text[:2000]
            try: detail=r.json().get('detail',detail)
            except Exception: pass
            raise HTTPException(502,f'local STT service: {detail}')
        out=r.json()
        store.event('speech.stt',{'text':out.get('text','')[:12000],'language':out.get('language'),'source':'local-whisper'})
        return out
    except HTTPException: raise
    except Exception as e: raise HTTPException(503,f'local STT service unavailable at {settings.stt_url}: {e}')

@app.post('/api/v1/speech/stt/ingest')
def speech_stt_ingest(req: STTIngestRequest):
    if not settings.speech_enabled: raise HTTPException(403,'speech disabled')
    body=req.model_dump(); body['text']=body['text'][:12000]
    store.event('speech.stt',body)
    return {'ok':True,'transcript':body['text'],'confidence':body.get('confidence'),'source':body.get('source')}

@app.get('/api/v1/emergence')
def emergence():
    guide=codex.reference('1 Thessalonians','5','21')
    return {
      'rule':'persona interpretation may form hypotheses, but physical claims require captured evidence',
      'codex_guidance':guide,
      'family_count':len(family.circle() or family.personas()),
      'signal_count':len(store.list_signals()),
      'write_control':settings.allow_write_control
    }

@app.get('/api/v1/codex/info')
def codex_info(): return codex.info()

@app.get('/api/v1/codex/reference')
def codex_reference(book:str,chapter:str,verse:str|None=None):
    x=codex.reference(book,chapter,verse)
    if x is None: raise HTTPException(404,'reference not found')
    return {'book':book,'chapter':chapter,'verse':verse,'text':x}

@app.websocket('/api/v1/events')
async def events(ws:WebSocket):
    await ws.accept(); seq=0
    try:
        while True:
            rows=store.recent_events(seq)
            for row in rows:
                seq=row['seq']; await ws.send_json(row)
            await asyncio.sleep(.8)
    except WebSocketDisconnect: return
