from __future__ import annotations
import json, os, sys, urllib.request, urllib.error

BASE=os.getenv('GROOT_URL', f"http://127.0.0.1:{os.getenv('GROOT_PORT','8787')}").rstrip('/')

def call(method,path,body=None):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(BASE+path,data=data,method=method,headers={'content-type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=30) as r:
            ctype=r.headers.get('content-type','')
            return json.loads(r.read()) if 'json' in ctype else r.read()
    except urllib.error.HTTPError as e:
        print(e.read().decode(),file=sys.stderr)
        raise

def out(x):
    print(json.dumps(x,indent=2) if not isinstance(x,(bytes,bytearray)) else f'{len(x)} bytes')

def main(argv=None):
    a=list(sys.argv[1:] if argv is None else argv) or ['help']
    cmd=a[0]
    if cmd=='status': out(call('GET','/api/v1/health'))
    elif cmd=='signals': out(call('GET','/api/v1/signals'))
    elif cmd=='streams': out(call('GET','/api/v1/streams'))
    elif cmd=='scan': out(call('POST','/api/v1/scan'))
    elif cmd=='neighbors': out(call('GET','/api/v1/neighbors'))
    elif cmd=='wifi-scan': out(call('POST','/api/v1/radio/wifi/scan'))
    elif cmd=='bt-scan': out(call('POST','/api/v1/radio/bluetooth/scan'))
    elif cmd=='discover' and len(a)>1: out(call('POST','/api/v1/control-plane/discover',{'target':a[1]}))
    elif cmd=='serial-sample' and len(a)>1: out(call('POST','/api/v1/control-plane/serial-sample',{'port':a[1],'baud':int(a[2]) if len(a)>2 else 9600}))
    elif cmd=='approve' and len(a)>2:
        scopes=[a[3]] if len(a)>3 else ['read']
        out(call('POST','/api/v1/control/approve',{'target':a[1],'transport':a[2],'scopes':scopes}))
    elif cmd=='exec' and len(a)>2:
        out(call('POST','/api/v1/control/execute',{'session_id':a[1],'command':' '.join(a[2:]),'username':os.getenv('GROOT_SSH_USER')}))
    elif cmd=='family': out(call('GET','/api/v1/family'))
    elif cmd=='day': out(call('GET','/api/v1/day/summary'))
    elif cmd=='talk' and len(a)>2:
        out(call('POST',f'/api/v1/talk/{a[1]}',{'message':' '.join(a[2:])}))
    elif cmd=='stream' and len(a)>2:
        out(call('POST',f'/api/v1/streams/{a[1]}/interact',{'action':a[2]}))
    elif cmd=='emergence': out(call('GET','/api/v1/emergence'))
    else:
        print('''usage:
  ./grootctl status|signals|streams|scan|neighbors|wifi-scan|bt-scan|family|day|emergence
  ./grootctl talk PERSONA_ID MESSAGE...
  ./grootctl stream SIGNAL_ID ACTION
  ./grootctl discover TARGET
  ./grootctl serial-sample PORT [BAUD]
  ./grootctl approve TARGET ssh|serial [read|write]
  ./grootctl exec SESSION_ID COMMAND...''')

if __name__ == '__main__':
    main()
