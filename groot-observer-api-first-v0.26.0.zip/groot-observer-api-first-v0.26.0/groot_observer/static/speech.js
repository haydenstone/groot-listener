export class SpeechDock {
  constructor(opts={}){
    this.onTranscript=opts.onTranscript||(()=>{});
    this.onStatus=opts.onStatus||(()=>{});
    this.getPersona=opts.getPersona||(()=>null);
    this.recognition=null;
    this.mediaRecorder=null;
    this.mediaStream=null;
    this.mediaChunks=[];
    this.recordTimer=null;
    this.listening=false;
    this.voices=[];
    this.serverVoices=[];
    this.statusInfo={};
    this.localWhisper=false;
    this.autoSpeak=localStorage.getItem('grootAutoSpeak')==='1';
    this.path=localStorage.getItem('grootVoicePath')||'server';
    this.voice=localStorage.getItem('grootVoice')||'';
    this.rate=Number(localStorage.getItem('grootVoiceRate')||1);
  }

  async init(){
    this.refreshBrowserVoices();
    window.speechSynthesis?.addEventListener?.('voiceschanged',()=>this.refreshBrowserVoices());
    await this.refreshStatus();
    try{
      const r=await fetch('/api/v1/speech/voices',{cache:'no-store'});
      const j=await r.json();
      this.serverVoices=j.server||[];
    }catch{}
    return this.statusInfo;
  }

  async refreshStatus(){
    try{
      const r=await fetch('/api/v1/speech/status',{cache:'no-store'});
      this.statusInfo=await r.json();
      this.localWhisper=!!this.statusInfo?.stt?.local_whisper;
    }catch(e){
      this.statusInfo={error:String(e)};
      this.localWhisper=false;
    }
    return this.statusInfo;
  }

  refreshBrowserVoices(){
    this.voices=window.speechSynthesis?window.speechSynthesis.getVoices():[];
  }

  availableVoices(path=this.path){
    return path==='server'
      ? this.serverVoices
      : this.voices.map(v=>({name:v.name,language:v.lang,voiceURI:v.voiceURI}));
  }

  setConfig({path,voice,rate,autoSpeak}={}){
    if(path){this.path=path;localStorage.setItem('grootVoicePath',path)}
    if(voice!==undefined){this.voice=voice;localStorage.setItem('grootVoice',voice)}
    if(rate!==undefined){this.rate=Number(rate)||1;localStorage.setItem('grootVoiceRate',this.rate)}
    if(autoSpeak!==undefined){this.autoSpeak=!!autoSpeak;localStorage.setItem('grootAutoSpeak',this.autoSpeak?'1':'0')}
  }

  stop(){
    try{window.speechSynthesis?.cancel()}catch{}
    const a=document.querySelector('#serverAudio');
    if(a){a.pause();a.removeAttribute('src')}
  }

  async speak(text,personaId=null){
    text=(text||'').trim();
    if(!text)return;
    this.stop();
    if(this.path==='server')return this.speakServer(text,personaId);
    if(!('speechSynthesis' in window))throw Error('Browser TTS is not available in this browser. Switch Voice Path to Server.');
    const u=new SpeechSynthesisUtterance(text);
    u.rate=this.rate;
    const v=this.voices.find(x=>x.voiceURI===this.voice||x.name===this.voice);
    if(v)u.voice=v;
    return new Promise((resolve,reject)=>{
      u.onend=()=>resolve();
      u.onerror=e=>reject(Error(`Browser TTS: ${e.error||'failed'}`));
      window.speechSynthesis.speak(u);
    });
  }

  async speakServer(text,personaId){
    const r=await fetch('/api/v1/speech/tts',{
      method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({text,voice:this.voice||null,persona_id:personaId,rate:this.rate,pitch:1})
    });
    if(!r.ok)throw Error((await r.text()).slice(0,500));
    const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.querySelector('#serverAudio');
    if(!a)throw Error('Speech audio element is missing from the UI.');
    a.src=url;
    a.onended=()=>URL.revokeObjectURL(url);
    a.onerror=()=>URL.revokeObjectURL(url);
    await a.play();
  }

  async toggleSTT(){
    if(this.listening)return this.stopSTT();
    await this.refreshStatus();
    if(this.localWhisper && navigator.mediaDevices?.getUserMedia && window.MediaRecorder){
      return this.startLocalRecorder();
    }
    return this.startBrowserRecognition();
  }

  async startLocalRecorder(){
    try{
      this.mediaStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
      const preferred=['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'];
      const mime=preferred.find(x=>window.MediaRecorder.isTypeSupported?.(x))||'';
      this.mediaChunks=[];
      this.mediaRecorder=new MediaRecorder(this.mediaStream,mime?{mimeType:mime}:undefined);
      this.mediaRecorder.ondataavailable=e=>{if(e.data?.size)this.mediaChunks.push(e.data)};
      this.mediaRecorder.onerror=e=>this.onStatus(`Mic error: ${e.error?.message||e.error||'unknown'}`);
      this.mediaRecorder.onstop=()=>this.finishLocalRecorder();
      this.mediaRecorder.start(250);
      this.listening=true;
      this.onStatus('recording locally · click mic to send');
      this.recordTimer=setTimeout(()=>this.stopSTT(),20000);
    }catch(e){
      this.cleanupRecorder();
      this.onStatus(`Mic: ${e.message||e}`);
      return this.startBrowserRecognition();
    }
  }

  async finishLocalRecorder(){
    clearTimeout(this.recordTimer);
    const mime=this.mediaRecorder?.mimeType||'audio/webm';
    const blob=new Blob(this.mediaChunks,{type:mime});
    this.cleanupRecorder(false);
    if(!blob.size){this.listening=false;this.onStatus('idle');return}
    this.onStatus('transcribing locally…');
    try{
      const fd=new FormData();
      const ext=mime.includes('ogg')?'ogg':'webm';
      fd.append('file',blob,`groot-mic.${ext}`);
      const r=await fetch('/api/v1/speech/stt',{method:'POST',body:fd});
      if(!r.ok)throw Error((await r.text()).slice(0,600));
      const out=await r.json();
      const t=String(out.text||'').trim();
      this.onStatus(t?`heard · ${t}`:'no speech detected');
      if(t)this.onTranscript(t);
    }catch(e){
      this.onStatus(`Local STT failed · ${e.message||e}`);
    }finally{
      this.listening=false;
      setTimeout(()=>{if(!this.listening)this.onStatus('idle')},2200);
    }
  }

  cleanupRecorder(clearChunks=true){
    try{this.mediaStream?.getTracks()?.forEach(t=>t.stop())}catch{}
    this.mediaStream=null;
    if(clearChunks)this.mediaChunks=[];
    this.mediaRecorder=null;
  }

  startBrowserRecognition(){
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){
      this.onStatus(this.localWhisper?'Microphone capture unavailable.':'Speech is offline. Start the Compose speech profile with ./groot speech or ./groot full.');
      return;
    }
    const r=new SR();
    r.continuous=false;r.interimResults=true;r.lang=navigator.language||'en-US';
    let final='';
    r.onstart=()=>{this.listening=true;this.onStatus('listening · browser STT fallback')};
    r.onresult=e=>{let interim='';for(let i=e.resultIndex;i<e.results.length;i++){const t=e.results[i][0].transcript;if(e.results[i].isFinal)final+=t;else interim+=t}this.onStatus(interim||final||'listening')};
    r.onerror=e=>this.onStatus(`Browser STT: ${e.error}`);
    r.onend=async()=>{
      this.listening=false;this.onStatus('idle');
      const t=final.trim();
      if(t){
        try{await fetch('/api/v1/speech/stt/ingest',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({text:t,source:'browser-web-speech'})})}catch{}
        this.onTranscript(t);
      }
    };
    this.recognition=r;r.start();
  }

  stopSTT(){
    clearTimeout(this.recordTimer);
    if(this.mediaRecorder && this.mediaRecorder.state!=='inactive'){
      try{this.mediaRecorder.stop()}catch{}
      return;
    }
    try{this.recognition?.stop()}catch{}
  }
}
