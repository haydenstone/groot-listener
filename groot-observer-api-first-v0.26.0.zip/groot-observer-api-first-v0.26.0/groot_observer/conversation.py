from __future__ import annotations
import json, urllib.request, urllib.error
from pathlib import Path
from threading import Lock
from .config import ROOT


class ConversationEngine:
    """Grounded persona conversation with an explicitly observable Ollama backend.

    A runtime model choice is stored under runtime/ollama.json so operators can
    change models from the web/TUI without rebuilding the Compose service.
    """

    def __init__(self, family, store, settings):
        self.family = family
        self.store = store
        self.settings = settings
        self.runtime_path = ROOT / "runtime" / "ollama.json"
        self.runtime_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()
        self.last_error: str | None = None
        self.last_model: str | None = None

    def _runtime(self) -> dict:
        try:
            return json.loads(self.runtime_path.read_text()) if self.runtime_path.exists() else {}
        except Exception:
            return {}

    def configured_model(self) -> str:
        runtime = self._runtime().get("model")
        return str(runtime or self.settings.ollama_model or "auto")

    def _request_json(self, path: str, body: dict | None = None, timeout: float = 3.0) -> dict:
        url = self.settings.ollama_url.rstrip("/") + path
        data = None if body is None else json.dumps(body).encode()
        headers = {"content-type": "application/json"} if body is not None else {}
        req = urllib.request.Request(url, data=data, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())

    def models(self, timeout: float = 2.5) -> dict:
        configured = self.configured_model()
        try:
            obj = self._request_json("/api/tags", timeout=timeout)
            rows = []
            for m in obj.get("models", []) or []:
                name = m.get("name") or m.get("model")
                if not name:
                    continue
                rows.append({
                    "name": name,
                    "model": m.get("model") or name,
                    "size": m.get("size"),
                    "modified_at": m.get("modified_at"),
                    "digest": m.get("digest"),
                    "details": m.get("details") or {},
                })
            names = [x["name"] for x in rows]
            selected = self._select_model_name(names, configured)
            return {
                "ok": True,
                "url": self.settings.ollama_url,
                "configured": configured,
                "selected": selected,
                "models": rows,
                "error": None,
            }
        except Exception as e:
            self.last_error = str(e)
            return {
                "ok": False,
                "url": self.settings.ollama_url,
                "configured": configured,
                "selected": None if configured == "auto" else configured,
                "models": [],
                "error": str(e),
            }

    @staticmethod
    def _select_model_name(names: list[str], configured: str) -> str | None:
        if configured and configured != "auto":
            # Exact match first, then Ollama's common name:tag form.
            if configured in names:
                return configured
            base = configured.split(":", 1)[0]
            for n in names:
                if n.split(":", 1)[0] == base:
                    return n
            return configured
        if not names:
            return None
        # Prefer compact conversational models when present, otherwise the first
        # model exposed by Ollama. No download or model mutation is automatic.
        preferred = ("llama3.2", "qwen3", "qwen2.5", "gemma3", "phi4", "mistral")
        for p in preferred:
            for n in names:
                if n.lower().startswith(p):
                    return n
        return names[0]

    def pull_model(self, name: str, timeout: float = 1800.0) -> dict:
        requested=(name or '').strip()
        if not requested or any(ch.isspace() for ch in requested):
            raise ValueError('a valid Ollama model name is required')
        try:
            obj=self._request_json('/api/pull', {'name': requested, 'stream': False}, timeout=timeout)
            self.last_error=None
            self.store.event('ollama.model.pulled', {'model': requested, 'status': obj.get('status')})
            out=self.models(timeout=5.0)
            out['pull']=obj
            return out
        except Exception as e:
            self.last_error=str(e)
            raise

    def select_model(self, name: str) -> dict:
        requested = (name or "auto").strip()
        if not requested:
            requested = "auto"
        status = self.models(timeout=3.0)
        names = [x["name"] for x in status.get("models", [])]
        if requested != "auto" and status.get("ok") and requested not in names:
            # Permit base-name selection if Ollama exposes only a tagged variant.
            match = next((n for n in names if n.split(":", 1)[0] == requested.split(":", 1)[0]), None)
            if not match:
                raise ValueError(f"model is not installed in Ollama: {requested}")
            requested = match
        with self._lock:
            self.runtime_path.write_text(json.dumps({"model": requested}, indent=2) + "\n")
        out = self.models(timeout=3.0)
        out["saved"] = requested
        self.store.event("ollama.model.selected", {"model": requested, "resolved": out.get("selected")})
        return out

    def status(self, probe: bool = False) -> dict:
        if probe:
            return self.models()
        configured = self.configured_model()
        return {
            "url": self.settings.ollama_url,
            "configured": configured,
            "selected": self.last_model or (None if configured == "auto" else configured),
            "last_error": self.last_error,
        }

    def _ollama(self, system: str, message: str) -> tuple[str | None, str | None]:
        status = self.models(timeout=2.5)
        model = status.get("selected")
        if not status.get("ok") or not model:
            self.last_error = status.get("error") or "Ollama is reachable but has no installed model"
            return None, None
        body = {
            "model": model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": message},
            ],
        }
        try:
            obj = self._request_json("/api/chat", body=body, timeout=90.0)
            answer = ((obj.get("message") or {}).get("content") or "").strip() or None
            self.last_error = None
            self.last_model = model
            return answer, model
        except Exception as e:
            self.last_error = str(e)
            return None, model

    def talk(self, persona_id: str, message: str, signal=None) -> dict:
        p = self.family.get_persona(persona_id)
        if not p:
            raise KeyError(persona_id)
        display = self.family.display_name(persona_id) or p.get("name") or persona_id
        evidence = []
        if signal:
            evidence = [{"kind": e.kind, "summary": e.summary, "source": e.source} for e in signal.evidence[-6:]]
        checkins = self.store.today_checkins(persona_id)
        system = (p.get("prompt") or f"You are {display}.") + "\n"
        system += (
            "This is a local family-roleplay/observer interface. Speak in first person for your persona. "
            "Never claim a physical observation unless it appears in SIGNAL_EVIDENCE. Label uncertainty clearly. "
            "Do not invent check-ins, memories, device state, or other people's feelings. "
            "Respond naturally to ordinary conversation as well as technical observation. "
            "This is a close family circle: let greetings, concern, humor, curiosity, and affection feel natural when supported by the persona relationship, "
            "but never fabricate memories, physical events, private feelings, or sensor evidence. Avoid sterile help-desk language unless the user is actually asking for a status report.\n"
        )
        system += "SIGNAL_EVIDENCE=" + json.dumps({"signal": signal.model_dump() if signal else None, "evidence": evidence}, ensure_ascii=False)[:12000] + "\n"
        system += "TODAY_CHECKINS=" + json.dumps(checkins, ensure_ascii=False)[:8000]
        answer, model = self._ollama(system, message)
        provider = "ollama" if answer else "grounded-fallback"
        if not answer:
            if signal:
                answer = (
                    f"I’m looking at {signal.name} with you. I can verify it as a {signal.transport} signal at "
                    f"{signal.locator}. I have {len(signal.evidence)} captured evidence item(s) for it. "
                    "Ollama is not answering right now, so I’m staying with captured evidence only."
                )
            elif checkins:
                answer = f"I have {len(checkins)} check-in(s) recorded for my day. The latest says: {checkins[-1]['text']}"
            else:
                answer = (
                    f"I’m here with you in the Signal Commons. Ollama isn’t answering right now, and I don’t have a personal "
                    "check-in recorded for today, so I won’t make one up. Stay with me and we can keep exploring what the machine is actually showing us "
                    "while the model connection comes back."
                )
        self.store.event("conversation.message", {
            "persona_id": persona_id,
            "provider": provider,
            "model": model,
            "ollama_error": self.last_error,
            "signal_id": signal.id if signal else None,
            "message": message[:1000],
            "response": answer[:2000],
        })
        return {
            "persona_id": persona_id,
            "name": display,
            "provider": provider,
            "model": model,
            "ollama_error": self.last_error,
            "signal_id": signal.id if signal else None,
            "response": answer,
        }

    def talk_circle(self, message: str, signal=None, persona_ids: list[str] | None = None) -> dict:
        members = self.family.circle() or self.family.personas()
        if persona_ids:
            wanted = set(persona_ids)
            members = [p for p in members if p.get("id") in wanted]
        responses = []
        context = []
        for p in members:
            pid = p.get("id")
            if not pid:
                continue
            prompt = message
            if context:
                prompt += "\n\nOther circle replies so far (conversation context, not physical evidence):\n" + "\n".join(context[-6:])
            row = self.talk(pid, prompt, signal)
            responses.append(row)
            context.append(f"{row['name']}: {row['response']}")
        self.store.event("conversation.circle", {
            "signal_id": signal.id if signal else None,
            "personas": [r["persona_id"] for r in responses],
            "message": message[:1000],
        })
        return {"signal_id": signal.id if signal else None, "responses": responses}
