from __future__ import annotations
import os, tempfile, threading, time
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
import uvicorn

app=FastAPI(title='GROOT Local Speech Service',version='0.26.0')
_model=None
_model_error=None
_model_started_at=None
_lock=threading.Lock()


def _bool(name:str, default:bool=False)->bool:
    raw=os.getenv(name)
    if raw is None: return default
    return raw.strip().lower() in {'1','true','yes','on'}


def model():
    global _model,_model_error,_model_started_at
    if _model is not None:
        return _model
    with _lock:
        if _model is not None:
            return _model
        _model_started_at=time.time()
        try:
            from faster_whisper import WhisperModel
            name=os.getenv('GROOT_WHISPER_MODEL','tiny')
            device=os.getenv('GROOT_WHISPER_DEVICE','cpu')
            compute=os.getenv('GROOT_WHISPER_COMPUTE_TYPE','int8')
            _model=WhisperModel(name,device=device,compute_type=compute,download_root=os.getenv('GROOT_WHISPER_CACHE','/models'))
            _model_error=None
            return _model
        except Exception as e:
            _model_error=str(e)
            raise RuntimeError(f'faster-whisper unavailable: {e}')


def _warm_model():
    try: model()
    except Exception: pass


@app.on_event('startup')
def preload_model():
    # Warm in the background so the API health endpoint appears quickly while
    # the tiny model downloads/loads on first boot.
    if _bool('GROOT_WHISPER_PRELOAD',True):
        threading.Thread(target=_warm_model,name='groot-whisper-preload',daemon=True).start()


@app.get('/health')
def health():
    return {
        'ok':True,
        'model':os.getenv('GROOT_WHISPER_MODEL','tiny'),
        'device':os.getenv('GROOT_WHISPER_DEVICE','cpu'),
        'compute_type':os.getenv('GROOT_WHISPER_COMPUTE_TYPE','int8'),
        'loaded':_model is not None,
        'loading':_model is None and _model_started_at is not None and _model_error is None,
        'error':_model_error,
    }


@app.post('/warm')
def warm():
    try:
        model()
        return {'ok':True,'loaded':True,'model':os.getenv('GROOT_WHISPER_MODEL','tiny')}
    except Exception as e:
        raise HTTPException(503,str(e))


@app.post('/v1/audio/transcriptions')
async def transcription(file: UploadFile=File(...), language: str|None=Form(None)):
    data=await file.read()
    if not data: raise HTTPException(400,'empty audio file')
    if len(data) > 30*1024*1024: raise HTTPException(413,'audio file too large; limit is 30 MB')
    suffix=Path(file.filename or 'audio.webm').suffix or '.webm'
    path=None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix,delete=False) as tmp:
            tmp.write(data); path=tmp.name
        segments,info=model().transcribe(path,language=language or None,vad_filter=True,beam_size=1)
        text=' '.join(seg.text.strip() for seg in segments if seg.text.strip()).strip()
        return {'text':text,'language':getattr(info,'language',language),'duration':getattr(info,'duration',None),'provider':'faster-whisper'}
    except HTTPException: raise
    except Exception as e: raise HTTPException(500,str(e))
    finally:
        if path:
            try: os.unlink(path)
            except OSError: pass


def run():
    uvicorn.run(app,host=os.getenv('GROOT_SPEECH_HOST','127.0.0.1'),port=int(os.getenv('GROOT_SPEECH_PORT','8790')))


if __name__=='__main__': run()
