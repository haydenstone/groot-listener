from __future__ import annotations
import shutil, subprocess, tempfile
from pathlib import Path

def snapshot(device: str) -> bytes:
    """Capture one frame from an explicit V4L2 device using ffmpeg."""
    if not device.startswith('/dev/video'):
        raise ValueError('capture device must be an explicit /dev/videoN path')
    if not Path(device).exists():
        raise FileNotFoundError(device)
    if not shutil.which('ffmpeg'):
        raise RuntimeError('ffmpeg not installed')
    with tempfile.NamedTemporaryFile(suffix='.jpg') as f:
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-f','v4l2','-i',device,'-frames:v','1','-q:v','3','-y',f.name]
        p=subprocess.run(cmd,text=True,capture_output=True,timeout=12)
        if p.returncode:
            raise RuntimeError(p.stderr[-4000:] or 'ffmpeg capture failed')
        return Path(f.name).read_bytes()

def record_audio(device: str, seconds: int = 4) -> bytes:
    """Record a short mono 16 kHz WAV clip from one explicit ALSA capture endpoint."""
    if not device.startswith(('hw:','plughw:')):
        raise ValueError('audio capture device must be an explicit ALSA hw:/plughw: locator')
    if not shutil.which('arecord'):
        raise RuntimeError('arecord not installed')
    seconds=max(1,min(15,int(seconds)))
    cmd=['arecord','-q','-D',device,'-f','S16_LE','-r','16000','-c','1','-d',str(seconds),'-t','wav','-']
    p=subprocess.run(cmd,capture_output=True,timeout=seconds+8)
    if p.returncode:
        raise RuntimeError((p.stderr or b'arecord failed').decode(errors='replace')[-4000:])
    return p.stdout
