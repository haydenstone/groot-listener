from __future__ import annotations
import shlex, shutil, subprocess
from .discovery import command_is_read_only

class ControlRunner:
    def __init__(self, store, allow_write: bool=False):
        self.store=store; self.allow_write=allow_write
    def execute(self, session_id: str, command: str, username: str | None=None, port: int=22, serial_baud: int=9600):
        sess=self.store.session(session_id)
        if not sess: raise PermissionError('approval session missing or expired')
        write=not command_is_read_only(command)
        if write and ('write' not in sess['scopes'] or not self.allow_write):
            raise PermissionError('write command blocked; enable GROOT_ALLOW_WRITE_CONTROL=1 and approve write scope')
        if sess['transport']=='ssh':
            if not shutil.which('ssh'): raise RuntimeError('ssh client not installed')
            dest=f"{username}@{sess['target']}" if username else sess['target']
            argv=['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=accept-new','-o','ConnectTimeout=5','-p',str(port),'--',dest,command]
            p=subprocess.run(argv,text=True,capture_output=True,timeout=20)
            return {'argv':argv[:-1]+['<command>'],'returncode':p.returncode,'stdout':p.stdout[-20000:],'stderr':p.stderr[-8000:]}
        if sess['transport']=='serial':
            import serial, time
            with serial.Serial(sess['target'], baudrate=serial_baud, timeout=.3) as s:
                s.write((command+'\r\n').encode()); s.flush(); time.sleep(.25)
                data=s.read(20000)
            return {'returncode':0,'stdout':data.decode('utf-8','replace'),'stderr':''}
        raise RuntimeError('unsupported control transport')
