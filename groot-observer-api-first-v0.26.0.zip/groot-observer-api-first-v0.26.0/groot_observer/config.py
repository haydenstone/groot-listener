from __future__ import annotations
import json, os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def _env_bool(name: str, default: bool | None = None) -> bool | None:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}

@dataclass(frozen=True)
class Settings:
    api_host: str = "127.0.0.1"
    api_port: int = 8787
    scan_interval_seconds: float = 4.0
    allow_active_probe: bool = True
    allow_write_control: bool = False
    local_only: bool = True
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "llama3.2:3b"
    family_enabled: bool = True
    codex_path: str = "data/codex.json"
    speech_enabled: bool = True
    family_circle_path: str = "config/family_circle.json"
    voices_path: str = "config/voices.json"
    stt_url: str = "http://127.0.0.1:8790"

    @classmethod
    def load(cls) -> "Settings":
        path = Path(os.getenv("GROOT_SETTINGS", ROOT / "config/settings.json"))
        raw: dict = {}
        if path.exists():
            raw = json.loads(path.read_text())

        env_map = {
            "api_host": os.getenv("GROOT_HOST"),
            "api_port": os.getenv("GROOT_PORT"),
            "scan_interval_seconds": os.getenv("GROOT_SCAN_INTERVAL_SECONDS"),
            "ollama_url": os.getenv("GROOT_OLLAMA_URL"),
            "ollama_model": os.getenv("GROOT_OLLAMA_MODEL"),
            "codex_path": os.getenv("GROOT_CODEX_PATH"),
            "family_circle_path": os.getenv("GROOT_FAMILY_CIRCLE_PATH"),
            "voices_path": os.getenv("GROOT_VOICES_PATH"),
            "stt_url": os.getenv("GROOT_STT_URL"),
        }
        for key, value in env_map.items():
            if value is not None and value != "":
                raw[key] = value

        for key, env_name in {
            "allow_active_probe": "GROOT_ALLOW_ACTIVE_PROBE",
            "allow_write_control": "GROOT_ALLOW_WRITE_CONTROL",
            "local_only": "GROOT_LOCAL_ONLY",
            "family_enabled": "GROOT_FAMILY_ENABLED",
            "speech_enabled": "GROOT_SPEECH_ENABLED",
        }.items():
            value = _env_bool(env_name)
            if value is not None:
                raw[key] = value

        if "api_port" in raw:
            raw["api_port"] = int(raw["api_port"])
        if "scan_interval_seconds" in raw:
            raw["scan_interval_seconds"] = float(raw["scan_interval_seconds"])

        allowed = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in raw.items() if k in allowed})
