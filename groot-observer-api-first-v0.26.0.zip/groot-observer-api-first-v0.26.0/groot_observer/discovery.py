from __future__ import annotations
import json, re, shutil, socket, subprocess, time, uuid
from pathlib import Path
from .models import Device, Evidence
from .adapters.network import neighbor_evidence

DEFAULT_PORTS=[22,23,80,443,830,8291,8728]

class ControlPlaneDiscovery:
    def __init__(self, profiles_path: Path):
        raw=json.loads(profiles_path.read_text()) if profiles_path.exists() else {"profiles":[]}
        self.profiles=raw.get('profiles',[])

    def neighbors(self):
        result={'ip_neighbors': neighbor_evidence(), 'lldp': []}
        if shutil.which('lldpctl'):
            try:
                raw=subprocess.check_output(['lldpctl','-f','json'],text=True,stderr=subprocess.DEVNULL,timeout=3)
                result['lldp']=json.loads(raw)
            except Exception as e:
                result['lldp_error']=str(e)
        return result

    def target(self, target: str, ports: list[int] | None=None) -> Device:
        # Targeted only. Never expands to a subnet.
        ips=[]
        try:
            for x in socket.getaddrinfo(target,None):
                ip=x[4][0]
                if ip not in ips: ips.append(ip)
        except socket.gaierror: pass
        evidence=[Evidence(kind='dns',source='getaddrinfo',summary=f'Resolved explicit target {target}',data={'addresses':ips})]
        open_ports=[]; banners={}
        for port in (ports or DEFAULT_PORTS)[:32]:
            try:
                family=socket.AF_INET6 if ips and ':' in ips[0] else socket.AF_INET
                s=socket.socket(family,socket.SOCK_STREAM); s.settimeout(.45)
                if s.connect_ex((ips[0] if ips else target, int(port)))==0:
                    open_ports.append(int(port))
                    if port in (22,23):
                        try: banners[str(port)]=s.recv(512).decode('utf-8','replace').strip()
                        except Exception: pass
                s.close()
            except Exception: pass
        evidence.append(Evidence(kind='targeted-port-probe',source=target,summary='Checked a bounded management-port set on the explicit target only',data={'open_ports':open_ports,'banners':banners}))
        hints=' '.join(banners.values())+' '+target
        vendor=None; profile_id=None
        for p in self.profiles:
            if any(h.lower() in hints.lower() for h in p.get('hints',[])):
                vendor=p.get('vendor'); profile_id=p.get('id'); break
        if vendor is None:
            if 8291 in open_ports or 8728 in open_ports: vendor='MikroTik'; profile_id='mikrotik-routeros'
        transports=[]
        portmap={22:'ssh',23:'telnet',80:'http',443:'https',830:'netconf',8291:'winbox',8728:'routeros-api'}
        transports=[portmap[p] for p in open_ports if p in portmap]
        return Device(id='device:'+uuid.uuid5(uuid.NAMESPACE_DNS,target).hex[:16],name=target,vendor=vendor,management_addresses=ips or [target],transports=transports,profile_id=profile_id,evidence=evidence)

    def serial_sample(self, port: str, baud: int=9600, timeout: float=1.5):
        import serial
        start=time.time(); chunks=[]
        with serial.Serial(port=port, baudrate=baud, timeout=.2) as s:
            while time.time()-start < timeout and sum(map(len,chunks)) < 8192:
                b=s.read(512)
                if b: chunks.append(b)
        raw=b''.join(chunks)
        text=raw.decode('utf-8','replace')
        return {"port":port,"baud":baud,"bytes":len(raw),"text":text}


def command_is_read_only(command: str) -> bool:
    c=command.strip().lower()
    safe_prefixes=('show ','display ','get ','print ','/system resource print','/system routerboard print','/interface print','/ip address print')
    return c.startswith(safe_prefixes)
