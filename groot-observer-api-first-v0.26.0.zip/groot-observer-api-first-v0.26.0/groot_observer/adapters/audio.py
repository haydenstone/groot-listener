from __future__ import annotations
import hashlib, re, shutil, subprocess
from .base import SignalAdapter
from ..models import Signal, Evidence

class AudioAdapter(SignalAdapter):
    kind='audio'
    def scan(self):
        if not shutil.which('arecord'): return []
        try:
            text=subprocess.check_output(['arecord','-l'],text=True,stderr=subprocess.DEVNULL,timeout=3)
        except Exception:
            return []
        out=[]
        # Example: card 1: Device [USB Audio Device], device 0: USB Audio [USB Audio]
        rx=re.compile(r'^card\s+(\d+):\s*([^\[]+)\[([^\]]+)\],\s*device\s+(\d+):\s*([^\[]+)\[([^\]]+)\]',re.I)
        for line in text.splitlines():
            m=rx.search(line.strip())
            if not m: continue
            card,card_id,card_name,dev,dev_id,dev_name=m.groups()
            locator=f'hw:{card},{dev}'
            name=(dev_name or card_name or f'Audio {locator}').strip()
            meta={'card':int(card),'device':int(dev),'card_id':card_id.strip(),'card_name':card_name.strip(),'device_id':dev_id.strip(),'device_name':dev_name.strip(),'alsa':locator}
            sid='audio:'+hashlib.sha1(locator.encode()).hexdigest()[:16]
            out.append(Signal(id=sid,transport='audio',name=name,locator=locator,confidence=.92,capabilities=['audio-capture','record-sample','stt-candidate'],metadata=meta,evidence=[Evidence(kind='alsa-capture',source='arecord -l',summary='ALSA audio capture endpoint discovered',data=meta)]))
        return out
