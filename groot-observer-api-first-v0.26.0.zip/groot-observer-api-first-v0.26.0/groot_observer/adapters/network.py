from __future__ import annotations
import hashlib, json, shutil, subprocess
from .base import SignalAdapter
from ..models import Signal, Evidence

def run_json(cmd):
    try: return json.loads(subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL, timeout=2))
    except Exception: return []

class NetworkAdapter(SignalAdapter):
    kind='network'
    def scan(self):
        links=run_json(['ip','-json','link','show']) if shutil.which('ip') else []
        addrs=run_json(['ip','-json','addr','show']) if shutil.which('ip') else []
        amap={a.get('ifname'):a for a in addrs}
        out=[]
        for x in links:
            ifname=x.get('ifname');
            if not ifname or ifname=='lo': continue
            info=amap.get(ifname,{})
            meta={"ifname":ifname,"address":x.get('address'),"operstate":x.get('operstate'),"mtu":x.get('mtu'),"addr_info":info.get('addr_info',[]),"link_type":x.get('link_type')}
            transport='wifi' if ifname.startswith(('wl','wlan')) else 'ethernet'
            caps=['ip','neighbor-discovery','targeted-control-plane-probe']
            sid=f'{transport}:'+hashlib.sha1(ifname.encode()).hexdigest()[:16]
            out.append(Signal(id=sid,transport=transport,name=ifname,locator=ifname,state='up' if x.get('operstate')=='UP' else 'down',confidence=.98,capabilities=caps,metadata=meta,evidence=[Evidence(kind='linux-link',source='iproute2',summary=f'{transport} interface {ifname} enumerated',data=meta)]))
        return out

def neighbor_evidence():
    rows=run_json(['ip','-json','neigh','show']) if shutil.which('ip') else []
    return rows
