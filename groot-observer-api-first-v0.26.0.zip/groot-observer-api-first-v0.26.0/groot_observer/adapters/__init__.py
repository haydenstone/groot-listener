from .usb import USBAdapter
from .serial import SerialAdapter
from .network import NetworkAdapter
from .bluetooth import BluetoothAdapter
from .video import VideoAdapter
from .audio import AudioAdapter

def default_adapters():
    return [USBAdapter(), SerialAdapter(), NetworkAdapter(), BluetoothAdapter(), VideoAdapter(), AudioAdapter()]
