from __future__ import annotations
import hashlib, glob
from .base import SignalAdapter
from ..models import Signal, Evidence

class SerialAdapter(SignalAdapter):
    kind='serial'
    def scan(self):
        ports=[]
        try:
            from serial.tools import list_ports
            for p in list_ports.comports():
                ports.append({"device":p.device,"description":p.description,"hwid":p.hwid,"vid":p.vid,"pid":p.pid,"manufacturer":p.manufacturer,"product":p.product,"serial_number":p.serial_number})
        except Exception:
            for dev in glob.glob('/dev/ttyUSB*')+glob.glob('/dev/ttyACM*'):
                ports.append({"device":dev,"description":"serial device"})
        out=[]
        for p in ports:
            sid='serial:'+hashlib.sha1(p['device'].encode()).hexdigest()[:16]
            desc=(p.get('description') or '').strip()
            name=p['device'] if desc.lower() in {'','n/a','unknown','none'} else f"{desc} · {p['device']}"
            out.append(Signal(id=sid,transport='serial',name=name,locator=p['device'],confidence=.95,capabilities=['console','read','write-with-approval'],metadata=p,evidence=[Evidence(kind='serial-enumeration',source=p['device'],summary='Serial endpoint discovered',data=p)]))
        return out
