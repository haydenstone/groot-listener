from __future__ import annotations
from abc import ABC, abstractmethod
from ..models import Signal

class SignalAdapter(ABC):
    kind: str
    @abstractmethod
    def scan(self) -> list[Signal]: ...
