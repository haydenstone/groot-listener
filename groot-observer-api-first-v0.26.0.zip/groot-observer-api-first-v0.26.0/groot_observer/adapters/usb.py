from __future__ import annotations
import hashlib
from pathlib import Path
from .base import SignalAdapter
from ..models import Signal, Evidence

class USBAdapter(SignalAdapter):
    kind = "usb"
    def scan(self):
        out=[]
        root=Path('/sys/bus/usb/devices')
        if not root.exists(): return out
        for d in root.iterdir():
            if not (d/'idVendor').exists(): continue
            def read(name):
                try: return (d/name).read_text().strip()
                except Exception: return None
            meta={k:read(k) for k in ['idVendor','idProduct','manufacturer','product','serial','bDeviceClass']}
            sid='usb:'+hashlib.sha1(str(d).encode()).hexdigest()[:16]
            name=' '.join(x for x in [meta.get('manufacturer'),meta.get('product')] if x) or d.name
            caps=['hotplug']
            if any(x in (meta.get('product') or '').lower() for x in ['serial','uart','rs232']): caps.append('serial-candidate')
            if any(x in (meta.get('product') or '').lower() for x in ['ethernet','lan','network']): caps.append('ethernet-candidate')
            out.append(Signal(id=sid,transport='usb',name=name,locator=str(d),confidence=.9,capabilities=caps,metadata=meta,evidence=[Evidence(kind='sysfs',source=str(d),summary='USB device enumerated by Linux sysfs',data=meta)]))
        return out
