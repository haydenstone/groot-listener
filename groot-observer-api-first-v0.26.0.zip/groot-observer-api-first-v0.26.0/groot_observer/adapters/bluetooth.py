from __future__ import annotations
import hashlib, shutil, subprocess
from .base import SignalAdapter
from ..models import Signal, Evidence

class BluetoothAdapter(SignalAdapter):
    kind='bluetooth'
    def scan(self):
        if not shutil.which('bluetoothctl'): return []
        try:
            text=subprocess.check_output(['bluetoothctl','devices'],text=True,stderr=subprocess.DEVNULL,timeout=2)
        except Exception: return []
        out=[]
        for line in text.splitlines():
            parts=line.split(' ',2)
            if len(parts)<3 or parts[0] != 'Device': continue
            mac,name=parts[1],parts[2]
            sid='bluetooth:'+hashlib.sha1(mac.encode()).hexdigest()[:16]
            out.append(Signal(id=sid,transport='bluetooth',name=name,locator=mac,confidence=.85,capabilities=['known-device','connect-on-explicit-request'],metadata={'mac':mac},evidence=[Evidence(kind='bluetoothctl',source='bluetoothctl devices',summary='Known Bluetooth device reported by BlueZ',data={'mac':mac,'name':name})]))
        return out
