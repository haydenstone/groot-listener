from __future__ import annotations
import glob, hashlib, os, shutil, subprocess
from .base import SignalAdapter
from ..models import Signal, Evidence

class VideoAdapter(SignalAdapter):
    kind='video'
    def scan(self):
        out=[]
        for dev in glob.glob('/dev/video*'):
            meta={'device':dev}
            if shutil.which('v4l2-ctl'):
                try:
                    meta['v4l2']=subprocess.check_output(['v4l2-ctl','-D','-d',dev],text=True,stderr=subprocess.DEVNULL,timeout=2)[:6000]
                except Exception: pass
            name=os.path.basename(dev)
            if 'v4l2' in meta:
                for line in meta['v4l2'].splitlines():
                    if 'Card type' in line: name=line.split(':',1)[-1].strip() or name
            sid='video:'+hashlib.sha1(dev.encode()).hexdigest()[:16]
            out.append(Signal(id=sid,transport='video',name=name,locator=dev,confidence=.9,capabilities=['v4l2','preview-candidate','hdmi-capture-if-supported'],metadata=meta,evidence=[Evidence(kind='v4l2',source=dev,summary='Video capture endpoint discovered. HDMI is observable only when hardware exposes an input/capture device.',data=meta)]))
        return out
