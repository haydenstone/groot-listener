from __future__ import annotations
import re, shutil, subprocess, time

def wifi_scan():
    """Explicit, operator-triggered Wi-Fi discovery. Does not connect to networks."""
    if not shutil.which('nmcli'):
        return {'available':False,'reason':'nmcli not installed','networks':[]}
    cmd=['nmcli','-t','--escape','yes','-f','IN-USE,SSID,BSSID,SIGNAL,SECURITY,FREQ','device','wifi','list','--rescan','yes']
    try:
        text=subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT,timeout=15)
    except subprocess.CalledProcessError as e:
        return {'available':True,'error':e.output[-4000:],'networks':[]}
    except Exception as e:
        return {'available':True,'error':str(e),'networks':[]}
    def split_escaped(line):
        out=[]; cur=[]; esc=False
        for ch in line:
            if esc: cur.append(ch); esc=False
            elif ch=='\\': esc=True
            elif ch==':': out.append(''.join(cur)); cur=[]
            else: cur.append(ch)
        out.append(''.join(cur)); return out
    rows=[]
    for line in text.splitlines():
        p=split_escaped(line)
        if len(p)<6: continue
        rows.append({'in_use':p[0]=='*','ssid':p[1], 'bssid':p[2], 'signal':int(p[3] or 0), 'security':p[4], 'frequency_mhz':int(p[5] or 0)})
    return {'available':True,'networks':rows}

def bluetooth_scan(timeout_seconds: int=8):
    """Explicit, bounded Bluetooth scan through BlueZ. Does not pair or connect."""
    if not shutil.which('bluetoothctl'):
        return {'available':False,'reason':'bluetoothctl not installed','devices':[]}
    timeout_seconds=max(2,min(int(timeout_seconds),20))
    try:
        subprocess.run(['bluetoothctl','--timeout',str(timeout_seconds),'scan','on'],text=True,capture_output=True,timeout=timeout_seconds+3)
        text=subprocess.check_output(['bluetoothctl','devices'],text=True,stderr=subprocess.DEVNULL,timeout=3)
    except Exception as e:
        return {'available':True,'error':str(e),'devices':[]}
    rows=[]
    for line in text.splitlines():
        p=line.split(' ',2)
        if len(p)==3 and p[0]=='Device': rows.append({'mac':p[1],'name':p[2]})
    return {'available':True,'devices':rows}
