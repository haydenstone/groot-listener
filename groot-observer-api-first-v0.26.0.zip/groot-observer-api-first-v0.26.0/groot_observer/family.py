from __future__ import annotations
import json
from pathlib import Path
from .models import Signal

class FamilyCouncil:
    def __init__(self, path: Path, circle_path: Path | None=None):
        self.path=path
        self.doc=json.loads(path.read_text()) if path.exists() else {"personas":[]}
        self.circle_doc=json.loads(circle_path.read_text()) if circle_path and circle_path.exists() else {"members":[]}
        self._by_id={p.get('id'):p for p in self.doc.get('personas',[]) if p.get('id')}
        self._circle={m.get('persona_id'):m for m in self.circle_doc.get('members',[]) if m.get('persona_id')}

    def get_persona(self, persona_id: str):
        return self._by_id.get(persona_id)

    def display_name(self, persona_id: str):
        m=self._circle.get(persona_id,{})
        p=self._by_id.get(persona_id,{})
        return m.get('display_name') or p.get('name')

    def personas(self):
        return [p for p in self.doc.get('personas',[]) if p.get('category')=='family']

    def circle(self):
        rows=[]
        for member in self.circle_doc.get('members',[]):
            p=self._by_id.get(member.get('persona_id'))
            if not p: continue
            x={k:v for k,v in p.items() if k != 'prompt'}
            x['display_name']=member.get('display_name') or p.get('name')
            x['voice_hint']=member.get('voice_hint')
            x['tone']=member.get('tone')
            x['greeting']=member.get('greeting')
            x['proximity']=member.get('proximity')
            if member.get('emoji'): x['emoji']=member.get('emoji')
            rows.append(x)
        return rows

    def focus(self, signal: Signal, ids: list[str] | None=None):
        people=self.circle() or self.personas()
        if ids: people=[p for p in people if p.get('id') in ids]
        conf=max(0.05,min(1.0,signal.confidence))
        distance=round(1.15-(0.85*conf),3)
        rows=[]
        for i,p in enumerate(people):
            angle=round((i/max(1,len(people)))*360,1)
            rows.append({
                "persona_id":p.get('id'),"name":p.get('display_name') or p.get('name'),"emoji":p.get('emoji'),
                "role":p.get('role'),"signal_id":signal.id,"distance":distance,
                "angle_degrees":angle,
                "observation":f"I am focusing on {signal.name}. I will stay grounded in its captured evidence and label unknowns as unknowns."
            })
        return rows
