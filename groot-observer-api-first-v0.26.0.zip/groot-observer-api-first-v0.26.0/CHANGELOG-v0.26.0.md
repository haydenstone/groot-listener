# GROOT Observer v0.26.0

- Repaired speech as a local-first path: browser `MediaRecorder` → `/api/v1/speech/stt` → Compose `faster-whisper`.
- Speech sidecar is enabled in the default Compose profile set and can preload the tiny CPU/int8 model.
- Added live speech health reporting and a `./groot voice` emoji-grid diagnostics menu.
- Kept server TTS through `espeak-ng` plus selectable browser voices and text-selection readout.
- Rebuilt `/overlay` as a liquid 3D glass AR launcher with a single copy action instead of dumping bookmarklet source.
- Rebuilt the injected AR overlay as a compact observability lens with family/Ollama, GROOT signals, page reactive-surface discovery, and page-activity telemetry.
- Added persisted light/dark mode to the Commons, title screen, and AR surfaces.
- Updated local font stacks for a cleaner display/terminal aesthetic without shipping font binaries.
