from pathlib import Path
from groot_observer.models import Signal
from groot_observer.streams import stream_view, sort_streams
from groot_observer.family import FamilyCouncil

ROOT=Path(__file__).parents[1]

def test_stream_actions_are_capability_bounded():
    s=Signal(id='serial:x',transport='serial',name='USB Serial',locator='/dev/ttyUSB0',state='present',confidence=.95)
    view=stream_view(s)
    ids={x['id'] for x in view['actions']}
    assert 'serial-sample' in ids
    assert 'snapshot' not in ids


def test_family_circle_contains_requested_observers():
    f=FamilyCouncil(ROOT/'config/family.json',ROOT/'config/family_circle.json')
    rows=f.circle()
    ids={x['id'] for x in rows}
    assert {'ava-stone','ayoh','truce-stone','klus-stone','aether','frankie','samuel'} <= ids
    ether=next(x for x in rows if x['id']=='aether')
    assert ether['display_name']=='Ether'


def test_audio_stream_offers_explicit_stt_action():
    s=Signal(id='audio:x',transport='audio',name='USB Mic',locator='hw:1,0',state='present',confidence=.9)
    ids={x['id'] for x in stream_view(s)['actions']}
    assert 'audio-transcribe' in ids
