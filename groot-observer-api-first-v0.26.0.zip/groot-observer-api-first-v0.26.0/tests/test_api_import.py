from fastapi.testclient import TestClient
from groot_observer import __version__

def test_api_routes_and_health():
    from groot_observer.api import app
    paths={r.path for r in app.routes}
    assert '/api/v1/signals' in paths
    assert '/api/v1/control-plane/discover' in paths
    assert '/api/v1/radio/wifi/scan' in paths
    assert '/api/v1/video/snapshot' in paths
    assert '/api/v1/streams' in paths
    assert '/api/v1/speech/tts' in paths
    assert '/api/v1/speech/stt/ingest' in paths
    assert '/api/v1/speech/stt' in paths
    assert '/api/v1/talk/{persona_id}' in paths
    assert '/api/v1/db/summary' in paths
    assert '/api/v1/db/table/{table}' in paths
    assert '/api/v1/transit/journey' in paths
    with TestClient(app) as c:
        r=c.get('/api/v1/health')
        assert r.status_code==200
        assert r.json()['version']==__version__
