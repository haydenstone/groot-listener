from groot_observer.discovery import command_is_read_only

def test_read_only_commands():
    assert command_is_read_only('show version')
    assert command_is_read_only('/interface print')
    assert not command_is_read_only('configure terminal')
    assert not command_is_read_only('/ip address add address=1.2.3.4/24 interface=ether1')
