from pathlib import Path
from fastapi.testclient import TestClient

ROOT=Path(__file__).parents[1]

def test_first_person_world_assets_present():
    html=(ROOT/'groot_observer/static/index.html').read_text()
    js=(ROOT/'groot_observer/static/world3d.js').read_text()
    assert 'ENTER COMMONS' in html
    assert 'worldCanvas' in html
    assert 'requestPointerLock' in js
    assert "e.code==='KeyE'" in js
    assert "e.code==='Tab'" in js
    assert 'if(!this.pointer||this.packetTrain?.riding)' in js
    assert "document.addEventListener('focusin'" in js

def test_ollama_model_and_overlay_routes_are_exposed():
    from groot_observer.api import app
    paths=[r.path for r in app.routes]
    assert '/api/v1/ollama/models' in paths
    assert '/api/v1/ollama/model' in paths
    assert '/api/v1/ollama/pull' in paths
    assert '/overlay' in paths
    assert '/ar-overlay.js' in paths
    assert '/legacy/v19/ar-overlay.js' in paths
    # Static route for circle must be registered before the dynamic persona route.
    assert paths.index('/api/v1/talk/circle') < paths.index('/api/v1/talk/{persona_id}')

def test_frontend_and_overlay_page_load():
    from groot_observer.api import app
    with TestClient(app) as c:
        assert c.get('/').status_code == 200
        assert c.get('/overlay').status_code == 200
        assert c.get('/ar-overlay.js').status_code == 200

def test_v026_theme_and_overlay_launcher_are_compact():
    html=(ROOT/'groot_observer/static/index.html').read_text()
    overlay=(ROOT/'groot_observer/static/overlay.html').read_text()
    ar=(ROOT/'groot_observer/static/ar-overlay.js').read_text()
    assert 'titleThemeBtn' in html and 'themeBtn' in html
    assert 'COPY OVERLAY LOADER' in overlay
    assert '<textarea id="code"' not in overlay
    assert 'backdrop-filter:blur(30px)' in ar
    assert 'MutationObserver' in ar
    assert 'PAGE ACTIVITY' in ar


def test_v026_speech_is_local_first_and_profile_enabled():
    speech=(ROOT/'groot_observer/static/speech.js').read_text()
    env=(ROOT/'.env.example').read_text()
    compose=(ROOT/'docker-compose.yml').read_text()
    assert 'MediaRecorder' in speech
    assert "/api/v1/speech/stt" in speech
    assert 'localWhisper' in speech
    assert 'COMPOSE_PROFILES=ollama,speech' in env
    assert 'GROOT_WHISPER_PRELOAD' in compose
