from pathlib import Path
from groot_observer.codex import Codex

def test_codex_loads():
    c=Codex(Path(__file__).parents[1]/'data/codex.json')
    info=c.info()
    assert info['top_level_keys'] > 10
