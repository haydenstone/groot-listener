from fastapi.testclient import TestClient


def test_db_explorer_is_read_only_and_bounded():
    from groot_observer.api import app
    with TestClient(app) as c:
        s=c.get('/api/v1/db/summary')
        assert s.status_code == 200
        names={x['name'] for x in s.json()['tables']}
        assert {'signals','devices','events','sessions','checkins'} <= names
        t=c.get('/api/v1/db/table/events?limit=5')
        assert t.status_code == 200
        assert t.json()['limit'] == 5
        assert c.get('/api/v1/db/table/not_a_table').status_code == 404


def test_packet_station_rejects_non_http_destinations():
    from groot_observer.api import app
    with TestClient(app) as c:
        r=c.post('/api/v1/transit/journey',json={'url':'file:///etc/passwd','ttl':64})
        assert r.status_code == 400


def test_environment_has_machine_world_districts():
    from groot_observer.api import app
    with TestClient(app) as c:
        env=c.get('/api/v1/environment').json()
    kinds={d['kind'] for d in env['districts']}
    assert {'hardware','database','transit','gateway'} <= kinds
