from pathlib import Path
from groot_observer.family import FamilyCouncil
from groot_observer.models import CircleTalkRequest

ROOT=Path(__file__).parents[1]

def test_environment_exists():
    assert (ROOT/'config/environment.json').exists()

def test_circle_request_schema():
    x=CircleTalkRequest(message='hello',persona_ids=['ava-stone'])
    assert x.message == 'hello'
    assert x.persona_ids == ['ava-stone']

def test_family_avatar_metadata_reused():
    f=FamilyCouncil(ROOT/'config/family.json',ROOT/'config/family_circle.json')
    ava=f.get_persona('ava-stone')
    assert ava['avatar']['kind'] == 'humanoid'
    assert ava['avatar']['motion'] == 'walk'
