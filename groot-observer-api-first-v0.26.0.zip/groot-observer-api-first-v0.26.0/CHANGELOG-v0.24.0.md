# v0.25.0 - Inside the Machine

- Fixes movement leaking into UI typing: WASD is accepted only while the world canvas owns pointer lock; focusing any input, textarea, select, button, contenteditable surface, or world panel clears movement immediately.
- Enables the Ollama Compose profile by default for new installs, adds an Ollama healthcheck, TUI doctor/model controls, explicit model pull API/UI, installed-model detection, and runtime model selection.
- Adds a read-only Evidence Vault database explorer backed by safe table inventory and paginated table reads. It never accepts arbitrary SQL.
- Adds a richer sky, Motherboard Core, transport-colored hardware bus conduits, Evidence Vault, Packet Station, Web Gateway, and generated website destination portals.
- Adds a bounded packet-transit journey: craft an HTTP/HTTPS destination, observe DNS plus an optional single HTTP HEAD probe, ride a visual packet train, then arrive at a generated portal for the destination.
- Keeps packet travel evidence-grounded: no synthetic traceroute hops are claimed and no arbitrary raw-packet/source-address forging is exposed.
