# Welcome TUI and 3D Commons

## Two surfaces, two jobs

`./groot` is the operator surface. It starts/stops/rebuilds Docker Compose, manages profiles, exposes status/logs/shell access, and edits the small set of environment knobs that matter most.

The browser is the human surface. It opens directly into the 3D Signal Commons. It is not a server dashboard.

## Calm UI defaults

- Nearby stream rail starts collapsed.
- Calm mode renders only the highest-attention seven streams.
- Clicking a signal reveals only that stream's supported actions.
- Clicking an avatar opens conversation with that persona.
- The family focus endpoint moves avatars toward the selected signal.

## Modular speech

There is no speech textarea/deck. Speech is exposed as reusable capabilities:

- floating microphone: browser STT into the active persona conversation;
- audio-stream `RECORD + STT`: local Whisper profile through the signal API;
- selection reader: select text anywhere and press READ;
- per-message speaker button;
- small voice popover for provider/voice/rate;
- optional auto-speak of persona replies.

Speech code lives in `static/speech.js`, separate from the environment/conversation client.
