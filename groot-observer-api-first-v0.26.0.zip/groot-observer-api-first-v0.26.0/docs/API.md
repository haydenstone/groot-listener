# API surface

The API is the product boundary. Hardware adapters feed normalized signals into it; the UI and CLI are ordinary API clients.

## Observation

- `GET /api/v1/health`
- `GET /api/v1/capabilities`
- `GET /api/v1/signals`
- `POST /api/v1/scan`
- `GET /api/v1/neighbors`
- `GET /api/v1/devices`
- `WS /api/v1/events`

## Targeted control-plane discovery

- `POST /api/v1/control-plane/discover` with `{"target":"192.168.88.1"}`
- `POST /api/v1/control-plane/serial-sample` with `{"port":"/dev/ttyUSB0","baud":9600}`

Discovery is deliberately target-bounded. It never expands an address into a subnet sweep.

## Explicit control session

1. `POST /api/v1/control/approve` with a target, transport, scopes, and TTL.
2. `POST /api/v1/control/execute` with the returned session ID.

Read commands are accepted in read scope. Write commands require both write scope and `GROOT_ALLOW_WRITE_CONTROL=1`.

## Codex and family

- `GET /api/v1/codex/info`
- `GET /api/v1/codex/reference?book=...&chapter=...&verse=...`
- `GET /api/v1/family`
- `POST /api/v1/family/focus`

`codex.json` is treated as operator-supplied guidance/reference data. Sensor claims must always come from captured evidence, never from Codex or persona narration.

## Explicit radio/capture discovery

- `POST /api/v1/radio/wifi/scan` asks NetworkManager for nearby Wi-Fi advertisements. It does not connect.
- `POST /api/v1/radio/bluetooth/scan` performs a bounded BlueZ discovery window. It does not pair or connect.
- `GET /api/v1/video/snapshot?device=/dev/video0` captures one frame from an explicit V4L2 endpoint with ffmpeg.
- `GET /api/v1/emergence` exposes the current evidence/persona boundary and Codex guidance hook.

## Signal Commons additions (v0.23.0)

- `GET /api/v1/streams` sorted nearby streams and available actions
- `POST /api/v1/streams/{signal_id}/interact` invoke one capability-advertised read/observe action
- `GET /api/v1/streams/{signal_id}/snapshot` explicit V4L2 frame capture
- `GET /api/v1/family/circle` Signal Commons family circle
- `POST /api/v1/talk/{persona_id}` grounded persona conversation, optionally with `signal_id`
- `POST /api/v1/checkin` explicit daily check-in
- `GET /api/v1/day/summary` recorded check-ins and observed event counts
- `GET /api/v1/speech/voices` server TTS voice inventory
- `POST /api/v1/speech/tts` synthesize WAV using the selected server voice
- `POST /api/v1/speech/stt/ingest` ingest a browser STT transcript into the event bus
- `POST /api/v1/speech/stt` transcribe an uploaded recording through the optional local Whisper service

Audio input signals are enumerated through ALSA and can expose `audio-transcribe`, an explicit short recording plus local STT action. No microphone recording is started just because a device was discovered.

## Inside-the-machine additions (v0.25.0)

- `GET /api/v1/db/summary` lists the local evidence database tables and row counts.
- `GET /api/v1/db/table/{table}?limit=100&offset=0` reads a whitelisted table without arbitrary SQL.
- `POST /api/v1/transit/journey` creates a bounded HTTP/HTTPS packet journey using DNS and an optional single HTTP HEAD observation.
- `POST /api/v1/ollama/pull` explicitly asks the configured Ollama server to pull a named model.
