# Docker Compose runtime

GROOT Observer 0.26.0 runs as a Docker Compose application. The host does not need a Python virtual environment.

## Why host networking is the default

The observer is intended to inspect the laptop's real signal/control surfaces. Docker bridge mode would hide or replace much of that network context with a container-local network namespace. Therefore the default Compose service uses `network_mode: host` and the API itself binds to `127.0.0.1`.

Change the API port in `.env`:

```dotenv
GROOT_PORT=8788
```

No Docker `ports:` mapping is needed in host-network mode.

## Hardware access

The default hardware-lab profile uses:

- `privileged: true`
- `NET_ADMIN` and `NET_RAW`
- host `/dev` mounted at `/dev`
- host `/sys` mounted read-only
- host udev state mounted read-only
- host system D-Bus mounted read-only

This lets new USB serial adapters, USB Ethernet devices, Bluetooth/Wi-Fi control surfaces, and V4L2 capture devices appear in the running observer without recreating the container.

This is broad host access. It is appropriate for a dedicated local observability appliance, not an untrusted multi-tenant container. Set `GROOT_PRIVILEGED=false` when testing API-only behavior, understanding that some physical adapters will stop working.

## Commands

```bash
./scripts/install.sh
./scripts/start.sh
./scripts/status.sh
./scripts/logs.sh
./scripts/shell.sh
./scripts/compose-config.sh
./scripts/repair.sh
./scripts/uninstall.sh
```

`repair.sh` rebuilds the image without cache while preserving `config/`, `data/codex.json`, and `runtime/`.

`uninstall.sh` stops/removes containers but preserves data. `uninstall.sh --purge` also removes the built image, runtime database, and the optional GROOT Ollama volume.

## Direct Compose controls

```bash
docker compose up -d --build
docker compose restart groot-observer
docker compose logs -f groot-observer
docker compose exec groot-observer bash
docker compose config
docker compose down
```

Every Compose parameter can be edited in `docker-compose.yml`; common operational knobs are exposed in `.env`.

## Optional Ollama sidecar

```bash
docker compose --profile ollama up -d
```

Both containers share host networking. GROOT therefore reaches Ollama at `http://127.0.0.1:11434` by default. Do not start the Ollama profile if another host process already owns that port unless you change the Ollama configuration.
