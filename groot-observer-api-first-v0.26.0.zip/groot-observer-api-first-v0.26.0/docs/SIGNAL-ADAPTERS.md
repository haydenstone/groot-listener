# Signal adapter contract

Every adapter returns one or more normalized `Signal` objects with transport, locator, state, capabilities, metadata, and evidence.

Current adapters:

- USB: Linux sysfs enumeration and hotplug candidates.
- Serial: `/dev/ttyUSB*`, `/dev/ttyACM*`, and pyserial metadata.
- Ethernet/Wi-Fi: Linux interface state and addresses.
- Bluetooth: known BlueZ devices. Discovery scans are not started automatically.
- Video: V4L2 capture endpoints. An HDMI source is visible only through real HDMI-input/capture hardware.

Adding a new transport requires only a new `SignalAdapter` and registration in `adapters.default_adapters()`.
