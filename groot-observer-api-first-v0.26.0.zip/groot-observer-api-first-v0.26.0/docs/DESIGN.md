# API-first design

## Pipeline

`physical signal -> adapter -> normalized Signal -> evidence store -> device inference -> explicit control session -> UI/family observers`

The observer never treats a persona response as physical evidence. The family layer can focus attention on a signal, discuss captured evidence, and make hypotheses, but facts stay tied to machine-readable evidence records.

## Control-plane discovery examples

### USB RS-232 -> switch console

USB enumeration discovers the adapter, serial enumeration identifies `/dev/ttyUSB0`, and `serial-sample` can read bytes without transmitting. Once the operator explicitly approves a serial session, commands can be sent to that exact port.

### USB Ethernet -> switch management

The new interface appears as an Ethernet signal. Linux neighbor state and LLDP tooling, when installed, can supply local evidence. The operator can then run a targeted management-port probe against one exact candidate address. Fingerprints include Cisco IOS, ADTRAN AOS, and MikroTik RouterOS hints.

### HDMI source -> laptop

Most laptop HDMI ports are output-only. To observe an Alexa/Fire TV/console HDMI source, connect an HDMI capture device. When Linux exposes it as `/dev/videoN`, the video adapter registers it as a signal and the UI can move observers toward it.
