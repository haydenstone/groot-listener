# Signal Commons v0.26.0

Signal Commons turns the physical signal inventory into a shared observation surface.

## Stream model

`GET /api/v1/streams` ranks observed signals by state, confidence, freshness, transport and useful capabilities. Each row includes an `actions` array. The UI builds its buttons from that array rather than guessing what a stream can do.

Observation remains the default. Nearby means observed by the laptop. Stream buttons do not grant write access to network devices.

Typical actions:

- USB: inspect, family focus, ask about it
- serial: inspect, family focus, sample console
- Ethernet: inspect, family focus, neighbor evidence
- Wi-Fi: inspect, family focus, bounded Wi-Fi scan
- Bluetooth: inspect, family focus, bounded Bluetooth scan
- video/V4L2: inspect, family focus, snapshot
- audio/ALSA: inspect, family focus, explicit short recording + local STT

## Family circle

The default circle is configured in `config/family_circle.json` and currently includes Ava, Ayoh, Truce, Klus, Ether, Frankie and Samuel. It points to persona records in `config/family.json`. `aether` is displayed as `Ether` without mutating the original persona registry.

`POST /api/v1/talk/{persona_id}` can include a selected `signal_id`. Ollama is used when available. If it is unavailable, the API returns a deterministic evidence-grounded fallback rather than fabricating observations.

## Today / check-ins

`POST /api/v1/checkin` records an explicit check-in. `GET /api/v1/day/summary` only reports recorded check-ins and observed events. It does not infer moods or claim unrecorded experiences.

## Speech

Two TTS paths are available:

1. Browser Web Speech voices. These are fast and can expose many OS/browser voices.
2. Server TTS using `espeak-ng` inside the GROOT Compose image.

Highlight text anywhere in the UI and use the floating Read Selection button, or use the Voice Deck.

Browser STT uses `SpeechRecognition` / `webkitSpeechRecognition` when the browser supports it. Final transcripts are sent to `POST /api/v1/speech/stt/ingest` so speech becomes part of the evidence/event stream. An optional local Whisper sidecar is included as the Compose `speech` profile. The UI can either use browser live STT or record a short microphone clip and send it to local Whisper. Audio streams discovered through ALSA also expose an explicit RECORD + STT action.
