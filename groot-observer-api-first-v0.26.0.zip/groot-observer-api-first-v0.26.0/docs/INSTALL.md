# Install / run

## Requirements

- Linux host (Debian/Ubuntu is the primary target)
- Docker Engine or Docker Desktop
- Docker Compose v2 (`docker compose`)

No host Python, pip, `python3-venv`, FastAPI, or Uvicorn installation is required.

## First boot

```bash
cp .env.example .env
./scripts/install.sh
./scripts/start.sh
./scripts/status.sh
```

Open `http://127.0.0.1:8787` and `http://127.0.0.1:8787/docs`.

## Change parameters

Edit `.env`, then recreate the service:

```bash
nano .env
docker compose up -d --force-recreate groot-observer
```

Typical examples:

```dotenv
GROOT_PORT=8788
GROOT_SCAN_INTERVAL_SECONDS=2
GROOT_ALLOW_ACTIVE_PROBE=true
GROOT_ALLOW_WRITE_CONTROL=false
GROOT_PRIVILEGED=true
```

## Rebuild / rollback

```bash
./scripts/repair.sh
```

To stop/remove only the containers:

```bash
./scripts/uninstall.sh
```

For destructive local runtime/image cleanup:

```bash
./scripts/uninstall.sh --purge
```
