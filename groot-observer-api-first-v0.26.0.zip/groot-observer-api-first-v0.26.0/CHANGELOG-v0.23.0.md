# v0.23.0 - Enter the Commons

## First-person world
- New title screen with API/discovery/Ollama readiness before entering.
- Enter as the configured operator character or an adult family persona.
- Canvas-based first-person 3D viewer derived from the v0.19 city renderer.
- WASD walking, Shift sprint, mouse look, E interaction.
- Pointer lock automatically releases when a conversation, signal controls, model chooser, voice chooser, or discovery rail needs the mouse.
- Tab/Escape returns the cursor; click the world or press R to resume walking.

## Discovery-driven expansion
- Observed streams are placed into stable transport sectors in the world.
- New discoveries materialize as beacons rather than rows only.
- The walkable world radius expands as farther discoveries are added.
- CALM keeps only the highest-attention discoveries visible; ALL reveals the broader discovered frontier.
- Selecting a signal causes family NPCs to walk toward that discovery.

## Ollama
- Detect installed models through `/api/v1/ollama/models`.
- Select `auto` or a concrete installed model through `/api/v1/ollama/model`.
- Runtime model choice persists in `runtime/ollama.json` without rebuilding the container.
- The title screen and in-world status both expose the actual selected model.
- Fixed route registration so `/api/v1/talk/circle` is not swallowed by the dynamic persona route.

## v19 JS overlay lineage
- `/overlay` generates a one-line bookmark/DevTools loader with the current relay, token, and family seed.
- `/ar-overlay.js` is a v0.23-compatible floating-family overlay using the current Ollama and stream APIs.
- The original v0.19 overlay source is preserved at `/legacy/v19/ar-overlay.js` and `/static/ar-overlay-v19.js`.
