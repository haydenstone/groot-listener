# v0.22.0

- Adds `./groot` welcome TUI for Compose/server management.
- Replaces dashboard-style landing page with the 3D Signal Commons.
- Reuses the v0.19 city visual primitives: tilted environment, districts and resident/avatar tokens.
- Signals are rendered as spatial beacons; selecting one moves the family focus toward it.
- Nearby rail starts collapsed and Calm mode limits visible streams to seven.
- Splits speech into independent `static/speech.js` module.
- Removes the large speech menu/text boxes from the landing experience.
- Adds avatar-targeted push-to-talk, selected-text reading, per-message TTS and compact voice settings.
- Adds `POST /api/v1/talk/circle` for an evidence-grounded multi-person Ollama circle response.
- Adds `GET /api/v1/environment` for the scene layout.
